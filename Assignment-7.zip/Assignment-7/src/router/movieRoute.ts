import {Request , Response} from "express"
import commentDataObj from "../data/commentsData";
import movieDataObj from "../data/moviesData";

export class MovieRouter{
public routes(app) : void{
  app.route("/api/movies").get(async (req : Request, res : Response) => {
  try {
    let skipMovie : Number = 0;
    let takeMovie : Number = 20;
    if (req.query.skip) {
      skipMovie  = parseInt((req.query.skip).toString());
    }

    if (req.query.take) {
      takeMovie = parseInt((req.query.take).toString());
    }

    let allMovies = await movieDataObj.getAllMovies(skipMovie, takeMovie);
    res.json(allMovies);
  } catch (error) {
    res.status(404).json({ error: "Movies not found" });
  }
});

app.route("/api/movies/:id").get(async (req : Request, res : Response) => {
  if (!req.params.id) {
    res.status(404).json({ error: "Movie Id missing" });
    return;
  }

  try {
    let movie : any = await movieDataObj.getMovieById(req.params.id);
    res.json(movie);
  } catch (error) {
    res.status(404).json({ error: "Movie not found" });
  }
});

app.route("/api/movies").post(async (req : Request, res : Response) => {  
  if (
    !req.body ||
    !req.body.title ||
    !req.body.cast ||
    !req.body.info ||
    !req.body.plot ||
    !req.body.rating||
    !req.body.comments
  ) {
    console.log(req.body)
    res.status(404).json({ error: `Must supply all fields`});
    return;
  }

  let movieParamBody : any = req.body;

  try {
    let newMovie : any = await movieDataObj.createMovie(
      movieParamBody.title,
      movieParamBody.cast,
      movieParamBody.info,
      movieParamBody.plot,
      movieParamBody.rating,
      []
    );
    res.json(newMovie);
  } catch (error) {
    res.status(404).json({ error: "Cannot add new Movie" });
  }
});

app.route("/api/movies/:id").put(async (req : Request, res : Response) => {
  if (
    !req.params.id ||
    !req.body ||
    !req.body.title ||
    !req.body.cast ||
    !req.body.info ||
    !req.body.plot ||
    !req.body.rating 
  ) {
    res.status(404).json({ error: "Must supply all fields." });
    return;
  }

  let movieParamBody: any = req.body;

  try {
    let movie: any = await movieDataObj.getMovieById(req.params.id);

    let updateMovie: any = await movieDataObj.updateMovie(
      req.params.id,
      movieParamBody["title"],
      movieParamBody["cast"],
      movieParamBody["info"],
      movieParamBody["plot"],
      movieParamBody["rating"],
      movie["comments"]
    );
    res.json(updateMovie);
  } catch (error) {
    res.status(404).json({ error: "Cannot update Movie." });
  }
});

app.route("/api/movies/:id").patch(async (req : Request, res : Response) => {
  if (!req.params.id || !req.body || Object.keys(req.body).length === 0) {
    res.status(404).json({
      error: "Must provide atleast one field in request body.",
    });
    return;
  }

  let movieBody: any = req.body;

  try {
    let oldMovie: any = await movieDataObj.getMovieById(req.params.id);

    if (movieBody.title && movieBody.title != oldMovie.title) {
      oldMovie.title = movieBody.title;
    }

    if (movieBody.cast && movieBody.cast != oldMovie.cast) {
      oldMovie.cast = movieBody.cast;
    }

    if (movieBody.info && movieBody.info != oldMovie.info) {
      oldMovie.info = movieBody.info;
    }
    if (movieBody.plot && movieBody.plot != oldMovie.plot) {
      oldMovie.plot = movieBody.plot;
    }
    if (movieBody.rating && movieBody.rating != oldMovie.rating) {
      oldMovie.rating = movieBody.rating;
    }

    let updateMovie: any = await movieDataObj.updateMovie(
      req.params.id,
      oldMovie["title"],
      oldMovie["cast"],
      oldMovie["info"],
      oldMovie["plot"],
      oldMovie["rating"],
      oldMovie["comments"]
    );
    res.json(updateMovie);
  } catch (error) {
    res.status(404).json({ error: "Cannot update Movie." });
  }
});

app.route("/api/movies/:id/comments").post(async (req : Request, res : Response) => {
  if (!req.body || !req.body.name || !req.body.comment || !req.params.id) {
    res.status(404).json({ error: "Must supply all fields." });
    return;
  }

  let commentParamBody: any = req.body;
  try {
    let newComment: any = await commentDataObj.createComments(commentParamBody);
    res.json(newComment);

    let movie: any = await movieDataObj.getMovieById(req.params.id);

    let commentArray: Array<any> = movie["comments"];
    commentArray.push(newComment);

    let updateMovie: any = await movieDataObj.updateMovie(
      req.params.id,
      movie["title"],
      movie["cast"],
      movie["info"],
      movie["plot"],
      movie["rating"],
      commentArray
    );

    res.json(updateMovie);
  } catch (error) {
    res.status(404).json({ error: "Cannot add comment for given movie" });
  }
});

app.route("/api/movies/:movieId/:commentId").delete(async (req: Request, res: Response) => {
  if (!req.params.movieId && !req.params.commentId) {
    res.status(404).json({ error: "Must supply movie Id and comment Id" });
    return;
  }

  try {
    let movie: any = await movieDataObj.getMovieById(req.params.movieId);

    let commentArray: Array<any> = movie["comments"];

    if (
      !commentArray ||
      !Array.isArray(commentArray) ||
      commentArray.length === 0
    ) {
      throw "Empty comment array";
    }

    let deleteComment: any = await commentDataObj.getCommentById(
      commentArray,
      req.params.commentId
    );

    commentArray = await commentDataObj.deleteComment(
      commentArray,
      deleteComment["_id"]
    );

    let updateMovie: any = await movieDataObj.updateMovie(
      req.params.movieId,
      movie["title"],
      movie["cast"],
      movie["info"],
      movie["plot"],
      movie["rating"],
      commentArray
    );

    res.json(updateMovie);
  } catch (error) {
    res.status(404).json({ error: "Cannot delete Comment." });
    return;
  }
  });

  app.route("*", (req : Request, res: Response) => {
    res.sendStatus(404).json({ error: "Not found" });
  });
  
 }
}

