import { dbCollections } from "../config/collection";
const movieCollectionObj = dbCollections.getCollectionFn("movies");
const { v1: uuidv4 } = require("uuid");

class MovieClass{
getValidId(id : any) : any {
  if (!id) {
    throw "Given movie id is invalid";
  }

  if (typeof id != "object" && typeof id != "string") {
    throw "Provide movie id of type object or string ";
  }

  return id;
}

getValidNumber(num : Number) : Number{
  num = Number(num);

  if (!Number.isInteger(num)) {
    throw "Given value is invalid.";
  }
  if (num < 0) {
    throw "Given value is negative.";
  }
  return num;
}

getValidRating(rating : Number) : Number {
  if (!rating) {
    throw "Given rating is invalid";
  }

  if (typeof rating != "number") {
    throw "Given value is not a number.";
  }

  if (rating < 0) {
    throw "Given value is negative.";
  }

  return rating;
}

getValidString(str : String, variableName : String) : String {
  if (!str) {
    throw `Provided ${variableName} is invalid`;
  }

  if (typeof str != "string") {
    throw `Given ${str} is not a string`;
  }

  if (str.trim().length === 0) {
    throw `Given ${variableName} is empty`;
  }
  return str;
}

getValidCast(array : Array<any>) : Array<any> {
  array = this.getValidArray(array, "Cast");

  for (let obj of array) {
    if (!obj || !obj["firstName"] || !obj["lastName"]) {
      throw `Provided Cast info is invalid`;
    }
    if (typeof obj != "object") {
      throw `Given ${obj} is not an Object`;
    }

    if (Object.keys(obj).length != 2) {
      throw `Must provide only required fields.`;
    }

    if (obj["firstName"]) {
      obj["firstName"] = this.getValidString(obj["firstName"], "firstName");
    }

    if (obj["lastName"]) {
      obj["lastName"] = this.getValidString(obj["lastName"], "lastName");
    }
  }
  return array;
}

 getValidInformation(obj : any, variableName : String)  : any{
  if (!obj || !obj["director"] || !obj["yearReleased"]) {
    throw `Provided ${variableName} is invalid`;
  }
  if (typeof obj != "object") {
    throw `Given ${obj} is not an Object`;
  }

  if (Object.keys(obj).length != 2) {
    throw `Must provide only required fields.`;
  }

  if (obj["director"]) {
    obj["director"] = this.getValidString(obj["director"], "director");
  }

  if (obj["yearReleased"]) {
    obj["yearReleased"] = this.getValidRating(obj["yearReleased"]);
  }

  return obj;
}

getValidArray(array :Array<any>, variableName :String)  : Array<any>{
  if (!array) {
    throw `Provided ${variableName} is invalid`;
  }

  if (!Array.isArray(array)) {
    throw `Given ${array} is not an Array`;
  }

  if (array.length === 0) {
    throw `Given ${variableName} is empty`;
  }
  return array;
}

async getMovieById(id : any) : Promise<any>{
  id = this.getValidId(id);
  let movieObj = await movieCollectionObj();

  let movieData = await movieObj.findOne({ _id: id });

  if (movieData === null) {
    throw `Error :Cannot find movie with given id : ${id} into database`;
  }

  return movieData;
}

async getAllMovies(skipNumber : Number, limitNumber : Number) : Promise<any>{
  skipNumber = this.getValidNumber(skipNumber);
  limitNumber = this.getValidNumber(limitNumber);

  if (limitNumber === 0) {
    return [];
  }

  if (limitNumber > 100) {
    limitNumber = 100;
  }

  const movieObj = await movieCollectionObj();
  const allMovieData = await movieObj
    .find({})
    .skip(skipNumber)
    .limit(limitNumber)
    .toArray();

  if (allMovieData === null) {
    throw `No movie found in database`;
  }
  return allMovieData;
}

async createMovie(title : String, cast : Array<any>, info : Object, plot : String, rating : Number, comment : Array<Object>): Promise<any> {
  title = this.getValidString(title, "Movie Title");
  cast = this.getValidCast(cast);
  info = this.getValidInformation(info, "Information");
  plot = this.getValidString(plot, "Plot");
  rating = this.getValidRating(rating);
  
 
  let movieSchema = {
    _id: uuidv4(),
    title: title,
    cast: cast,
    info: info,
    plot: plot,
    rating: rating,
    comments: comment,
  };

  let movieObj = await movieCollectionObj();

  let newMovie = await movieObj.insertOne(movieSchema);

  if (newMovie.insertedCount === 0) {
    throw `Error : Unable to add new movie into database`;
  }

  return await this.getMovieById(newMovie.insertedId);
}
async updateMovie(id : any ,title : String, cast : Array<any>, info : Object, plot : String, rating : Number, comment : Array<Object>) : Promise<any> {
  id = this.getValidId(id);
  title = this.getValidString(title, "Movie Title");
  cast = this.getValidCast(cast);
  info = this.getValidInformation(info, "Information");
  plot = this.getValidString(plot, "Plot");
  rating = this.getValidRating(rating);

  let movieObj = await movieCollectionObj();

  let movieSchema = {
    title: title,
    cast: cast,
    info: info,
    plot: plot,
    rating: rating,
    comments: comment,
  };

  let updateMovie = await movieObj.updateOne(
    { _id: id },
    { $set: movieSchema }
  );

  if (!updateMovie.modifiedCount && !updateMovie.matchedCount) {
    throw `Error : Unable to update movie with id : ${id} into database`;
  }

  return await this.getMovieById(id);
}

async deleteMovie(id: any) : Promise<boolean>{
  id = this.getValidId(id);

  let movieObj = await movieCollectionObj();

  let removedMovie = await movieObj.removeOne({ _id: id });

  if (removedMovie.deletedCount === 0) {
    throw `Error : Unable to delete movie with id : ${id} from database`;
  }

  return true;
}
}

export default new MovieClass()