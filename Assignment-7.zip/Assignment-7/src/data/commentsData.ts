import { dbCollections } from "../config/collection";
const commentCollectionObj = dbCollections.getCollectionFn("comment");
const { v1: uuidv4 } = require("uuid");

class CommentClass{
  getValidString(str : String, variableName : String) : String {
  if (!str) {
    throw `Provided ${variableName} is invalid`;
  }

  if (typeof str != "string") {
    throw `Given ${str} is not a string`;
  }

  if (str.trim().length === 0) {
    throw `Given ${variableName} is empty`;
  }
  return str;
}

 getValidId(id : any) : any {
  if (!id) {
    throw "Given comment id is invalid";
  }

  if (typeof id != "object" && typeof id != "string") {
    throw "Provide comment id of type object or string ";
  }

  return id;
}

async  getCommentById(commentArray : Array<any>, id : any) {
  let currentId : any = this.getValidId(id);

  for (let obj of commentArray) {
    if (obj["_id"] === currentId) {
      return obj;
    }
  }

  throw `Cannot find comment with given id : ${id}`;
}

async createComments(commentParam : any) {
  let name : String = this.getValidString(commentParam["name"], "Name");
  let comment : String = this.getValidString(commentParam["comment"], "Comment");

  let commentSchema = {
    _id: uuidv4(),
    name: name,
    comment: comment,
  };

  return commentSchema;
}

async  deleteComment(commentArray :Array<any>, id : any) {
  let currentId : any = this.getValidId(id);
  for (let comment of commentArray) {
    let index = commentArray.indexOf(comment);
    if (currentId === comment._id.toString()) {
      commentArray.splice(index, 1);
      break;
    }
  }
  return commentArray;
}
}

export default new CommentClass();
