import * as express from "express";
import {Request , Response} from "express"
import {MovieRouter} from "./router/movieRoute";

class App {
  public app: express.Application;
  public movieRoute : MovieRouter = new MovieRouter();
  public totalRequestsDict = {};

  constructor() {
    this.app = express(); //run the express instance and store in app
    this.config(); 
    this.movieRoute.routes(this.app) 
  }

  private Logger = (req: express.Request, res: express.Response, next: Function) => {
        var totalRequest : number = 1
        let completeURL = req.method + req.url;
        if (completeURL in this.totalRequestsDict) {
            let count : number = this.totalRequestsDict[completeURL];
            count = count + 1;
            this.totalRequestsDict[completeURL] = count;
        } else {
            this.totalRequestsDict[completeURL] = 1;
        }

        totalRequest = totalRequest + 1;

        console.log(
            "---------------------------------------------------------------"
        );
        console.log(`There have been ${totalRequest} requests made to the server`);

        if (req.body) {
            console.log(`Request body : ${JSON.stringify(req.body)}`);
        }
        console.log(`URL Path : ${req.originalUrl} \n Http verb : ${req.method}`);

        console.log(
            `Total request made to URL : ${req.url} : ${this.totalRequestsDict[completeURL]}`
        );

        console.log(
            "---------------------------------------------------------------"
        );

        next();

    };

  private config(): void {
    this.app.use(express.json());
    this.app.use(express.urlencoded({extended : false}))
    this.app.use(this.Logger);
  }
}

export default new App().app;