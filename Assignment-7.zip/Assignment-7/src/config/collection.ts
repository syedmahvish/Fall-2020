import { dbconnection } from "./connection";
import settings = require("./setting.json");
var mongoConfig = settings.mongoConfig;

export class dbCollections {
  public static getCollectionFn = (collection) => {
    let _col = undefined;
    return async () => {
      await dbconnection.connect(mongoConfig.serverUrl);
      if (!_col) {
        _col = await dbconnection.client
          .db(mongoConfig.database)
          .collection(collection);
      }
      return _col;
    };
  };
}