const dbCollections = require("../config/collection");
const movieCollectionObj = dbCollections.movies;
const { v1: uuidv4 } = require("uuid");

function getValidId(id) {
  if (!id) {
    throw "Given movie id is invalid";
  }

  if (typeof id != "object" && typeof id != "string") {
    throw "Provide movie id of type object or string ";
  }

  return id;
}

function getValidNumber(num) {
  num = Number(num);

  if (!Number.isInteger(num)) {
    throw "Given value is invalid.";
  }
  if (num < 0) {
    throw "Given value is negative.";
  }
  return num;
}

function getValidRating(rating) {
  if (!rating) {
    throw "Given rating is invalid";
  }

  if (typeof rating != "number") {
    throw "Given value is not a number.";
  }

  if (rating < 0) {
    throw "Given value is negative.";
  }

  return rating;
}

function getValidString(str, variableName) {
  if (!str) {
    throw `Provided ${variableName} is invalid`;
  }

  if (typeof str != "string") {
    throw `Given ${str} is not a string`;
  }

  if (str.trim().length === 0) {
    throw `Given ${variableName} is empty`;
  }
  return str;
}

function getValidCast(array) {
  array = getValidArray(array, "Cast");

  for (let obj of array) {
    if (!obj || !obj["firstName"] || !obj["lastName"]) {
      throw `Provided Cast info is invalid`;
    }
    if (typeof obj != "object") {
      throw `Given ${obj} is not an Object`;
    }

    if (Object.keys(obj).length != 2) {
      throw `Must provide only required fields.`;
    }

    if (obj["firstName"]) {
      obj["firstName"] = getValidString(obj["firstName"], "firstName");
    }

    if (obj["lastName"]) {
      obj["lastName"] = getValidString(obj["lastName"], "lastName");
    }
  }
  return array;
}

function getValidInformation(obj) {
  if (!obj || !obj["director"] || !obj["yearReleased"]) {
    throw `Provided ${variableName} is invalid`;
  }
  if (typeof obj != "object") {
    throw `Given ${obj} is not an Object`;
  }

  if (Object.keys(obj).length != 2) {
    throw `Must provide only required fields.`;
  }

  if (obj["director"]) {
    obj["director"] = getValidString(obj["director"], "director");
  }

  if (obj["yearReleased"]) {
    obj["yearReleased"] = getValidRating(obj["yearReleased"], "yearReleased");
  }

  return obj;
}

function getValidArray(array, variableName) {
  if (!array) {
    throw `Provided ${variableName} is invalid`;
  }

  if (!Array.isArray(array)) {
    throw `Given ${array} is not an Array`;
  }

  if (array.length === 0) {
    throw `Given ${variableName} is empty`;
  }
  return array;
}

async function getMovieById(id) {
  id = getValidId(id);
  let movieObj = await movieCollectionObj();

  let movieData = await movieObj.findOne({ _id: id });

  if (movieData === null) {
    throw `Error :Cannot find movie with given id : ${id} into database`;
  }

  return movieData;
}

async function getAllMovies(skipNumber, limitNumber) {
  skipNumber = getValidNumber(skipNumber);
  limitNumber = getValidNumber(limitNumber);

  if (limitNumber === 0) {
    return [];
  }

  if (limitNumber > 100) {
    limitNumber = 100;
  }

  const movieObj = await movieCollectionObj();
  const allMovieData = await movieObj
    .find({})
    .skip(skipNumber)
    .limit(limitNumber)
    .toArray();

  if (allMovieData === null) {
    throw `No movie found in database`;
  }
  return allMovieData;
}

async function createMovie(title, cast, info, plot, rating, comment) {
  title = getValidString(title, "Movie Title");
  cast = getValidCast(cast, "Cast");
  info = getValidInformation(info, "Information");
  plot = getValidString(plot, "Plot");
  rating = getValidRating(rating);
  if (comment.length > 0) {
    throw "Comments should not Empty while creating movie.";
  }
  comments = comment;

  let movieSchema = {
    _id: uuidv4(),
    title: title,
    cast: cast,
    info: info,
    plot: plot,
    rating: rating,
    comments: comments,
  };

  let movieObj = await movieCollectionObj();

  let newMovie = await movieObj.insertOne(movieSchema);

  if (newMovie.insertedCount === 0) {
    throw `Error : Unable to add new movie into database`;
  }

  return await this.getMovieById(newMovie.insertedId);
}

async function updateMovie(id, title, cast, info, plot, rating, comment) {
  id = getValidId(id);
  title = getValidString(title, "Movie Title");
  cast = getValidCast(cast, "Cast");
  info = getValidInformation(info, "Information");
  plot = getValidString(plot, "Plot");
  rating = getValidRating(rating);

  let movieObj = await movieCollectionObj();

  let movieSchema = {
    title: title,
    cast: cast,
    info: info,
    plot: plot,
    rating: rating,
    comments: comment,
  };

  let updateMovie = await movieObj.updateOne(
    { _id: id },
    { $set: movieSchema }
  );

  if (!updateMovie.modifiedCount && !updateMovie.matchedCount) {
    throw `Error : Unable to update movie with id : ${id} into database`;
  }

  return await this.getMovieById(id);
}

async function deleteMovie(id) {
  id = getValidId(id);

  let movieObj = await movieCollectionObj();

  let removedMovie = await movieObj.removeOne({ _id: id });

  if (removedMovie.deletedCount === 0) {
    throw `Error : Unable to delete movie with id : ${id} from database`;
  }

  return true;
}

module.exports = {
  getAllMovies,
  getMovieById,
  createMovie,
  updateMovie,
  deleteMovie,
};
