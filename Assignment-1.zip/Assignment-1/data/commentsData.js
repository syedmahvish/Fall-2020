const dbCollections = require("../config/collection");
const commentCollectionObj = dbCollections.comments;
const { v1: uuidv4 } = require("uuid");

function getValidString(str, variableName) {
  if (!str) {
    throw `Provided ${variableName} is invalid`;
  }

  if (typeof str != "string") {
    throw `Given ${str} is not a string`;
  }

  if (str.trim().length === 0) {
    throw `Given ${variableName} is empty`;
  }
  return str;
}

function getValidId(id) {
  if (!id) {
    throw "Given comment id is invalid";
  }

  if (typeof id != "object" && typeof id != "string") {
    throw "Provide comment id of type object or string ";
  }

  return id;
}

async function getCommentById(commentArray, id) {
  id = getValidId(id);

  for (let obj of commentArray) {
    if (obj["_id"] === id) {
      return obj;
    }
  }

  throw `Cannot find comment with given id : ${id}`;
}

async function createComments(commentParam) {
  name = getValidString(commentParam["name"], "Name");
  comment = getValidString(commentParam["comment"], "Comment");

  let commentSchema = {
    _id: uuidv4(),
    name: name,
    comment: comment,
  };

  return commentSchema;
}

async function deleteComment(commentArray, id) {
  id = getValidId(id);
  for (let comment of commentArray) {
    let index = commentArray.indexOf(comment);
    if (id === comment._id.toString()) {
      commentArray.splice(index, 1);
      break;
    }
  }
  return commentArray;
}

async function checkComments(movieCommentArray, paramCommentArray) {
  if (movieCommentArray.length != paramCommentArray.length) {
    throw "Comments updated in Put/Patch request";
  }

  let index = 0;
  for (let moviecomment of movieCommentArray) {
    let paramComment = paramCommentArray[index];
    if (
      moviecomment._id.toString() != paramComment._id.toString() ||
      moviecomment.name != paramComment.name ||
      moviecomment.comment != paramComment.comment
    ) {
      throw "Comments updated in Put/Patch request";
    }

    index = index + 1;
  }

  return false;
}

module.exports = {
  getCommentById,
  createComments,
  deleteComment,
  checkComments,
};
