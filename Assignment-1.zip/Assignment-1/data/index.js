const movieData = require("./moviesData");
const commentData = require("./commentsData");
module.exports = { movie: movieData, comment: commentData };
