const express = require("express");
const app = express();
const configRoutes = require("./router/index");

app.use(express.json());

let totalRequestsDict = {};
let totalRequest = 0;

app.use(async (req, res, next) => {
  let completeURL = req.method + req.url;
  if (completeURL in totalRequestsDict) {
    let count = totalRequestsDict[completeURL];
    count++;
    totalRequestsDict[completeURL] = count;
  } else {
    totalRequestsDict[completeURL] = 1;
  }

  totalRequest++;

  console.log(
    "---------------------------------------------------------------"
  );
  console.log(`There have been ${totalRequest} requests made to the server`);

  if (req.body) {
    console.log(`Request body : ${JSON.stringify(req.body)}`);
  }
  console.log(`URL Path : ${req.originalUrl} \n Http verb : ${req.method}`);

  console.log(
    `Total request made to URL : ${req.url} : ${totalRequestsDict[completeURL]}`
  );

  console.log(
    "---------------------------------------------------------------"
  );

  next();
});

configRoutes(app);

app.listen(3000, () => {
  console.log("We've now got a server!");
  console.log("Your routes will be running on http://localhost:3000");
});
