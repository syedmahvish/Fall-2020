const express = require("express");
const router = express.Router();
const data = require("../data");
const { comments } = require("../config/collection");
const commentDataObj = data.comment;
const movieDataObj = data.movie;

router.get("/", async (req, res) => {
  try {
    let skipMovie = 0;
    let takeMovie = 20;
    if (req.query.skip) {
      skipMovie = req.query.skip;
    }

    if (req.query.take) {
      takeMovie = req.query.take;
    }

    let allMovies = await movieDataObj.getAllMovies(skipMovie, takeMovie);
    res.json(allMovies);
  } catch (error) {
    res.status(404).json({ error: "Movies not found" });
  }
});

router.get("/:id", async (req, res) => {
  if (!req.params.id) {
    res.status(404).json({ error: "Movie Id missing" });
    return;
  }

  try {
    let movie = await movieDataObj.getMovieById(req.params.id);
    res.json(movie);
  } catch (error) {
    res.status(404).json({ error: "Movie not found" });
  }
});

router.post("/", async (req, res) => {
  if (
    !req.body ||
    !req.body.title ||
    !req.body.cast ||
    !req.body.info ||
    !req.body.plot ||
    !req.body.rating ||
    !req.body.comments
  ) {
    res.status(404).json({ error: "Must supply all fields." });
    return;
  }

  let movieParamBody = req.body;
  try {
    let newMovie = await movieDataObj.createMovie(
      movieParamBody.title,
      movieParamBody.cast,
      movieParamBody.info,
      movieParamBody.plot,
      movieParamBody.rating,
      movieParamBody.comments
    );
    res.json(newMovie);
  } catch (error) {
    res.status(404).json({ error: "Cannot add new Movie" });
  }
});

router.put("/:id", async (req, res) => {
  if (
    !req.params.id ||
    !req.body ||
    !req.body.title ||
    !req.body.cast ||
    !req.body.info ||
    !req.body.plot ||
    !req.body.rating ||
    !req.body.comments
  ) {
    res.status(404).json({ error: "Must supply all fields." });
    return;
  }

  let movieParamBody = req.body;

  try {
    let movie = await movieDataObj.getMovieById(req.params.id);

    await commentDataObj.checkComments(
      movie["comments"],
      movieParamBody["comments"]
    );

    let updateMovie = await movieDataObj.updateMovie(
      req.params.id,
      movieParamBody["title"],
      movieParamBody["cast"],
      movieParamBody["info"],
      movieParamBody["plot"],
      movieParamBody["rating"],
      movieParamBody["comments"]
    );
    res.json(updateMovie);
  } catch (error) {
    res.status(404).json({ error: "Cannot update Movie." });
  }
});

router.patch("/:id", async (req, res) => {
  if (!req.params.id || !req.body || Object.keys(req.body).length === 0) {
    res.status(404).json({
      error: "Must provide atleast one field in request body.",
    });
    return;
  }

  let movieBody = req.body;
  let oldMovie = {};

  try {
    oldMovie = await movieDataObj.getMovieById(req.params.id);

    if (movieBody.title && movieBody.title != oldMovie.title) {
      oldMovie.title = movieBody.title;
    }

    if (movieBody.cast && movieBody.cast != oldMovie.cast) {
      oldMovie.cast = movieBody.cast;
    }

    if (movieBody.info && movieBody.info != oldMovie.info) {
      oldMovie.info = movieBody.info;
    }
    if (movieBody.plot && movieBody.plot != oldMovie.plot) {
      oldMovie.plot = movieBody.plot;
    }
    if (movieBody.rating && movieBody.rating != oldMovie.rating) {
      oldMovie.rating = movieBody.rating;
    }

    await commentDataObj.checkComments(
      movieBody["comments"],
      oldMovie["comments"]
    );

    let updateMovie = await movieDataObj.updateMovie(
      req.params.id,
      oldMovie["title"],
      oldMovie["cast"],
      oldMovie["info"],
      oldMovie["plot"],
      oldMovie["rating"],
      oldMovie["comments"]
    );
    res.json(updateMovie);
  } catch (error) {
    res.status(404).json({ error: "Cannot update Movie." });
  }
});

router.post("/:id/comments", async (req, res) => {
  if (!req.body || !req.body.name || !req.body.comment || !req.params.id) {
    res.status(404).json({ error: "Must supply all fields." });
    return;
  }

  let commentParamBody = req.body;
  try {
    let newComment = await commentDataObj.createComments(commentParamBody);
    res.json(newComment);

    let movie = await movieDataObj.getMovieById(req.params.id);

    let commentArray = movie["comments"];
    commentArray.push(newComment);

    let updateMovie = await movieDataObj.updateMovie(
      req.params.id,
      movie["title"],
      movie["cast"],
      movie["info"],
      movie["plot"],
      movie["rating"],
      commentArray
    );

    res.json(updateMovie);
  } catch (error) {
    res.status(404).json({ error: "Cannot add comment for given movie" });
  }
});

router.delete("/:movieId/:commentId", async (req, res) => {
  if (!req.params.movieId && !req.params.commentId) {
    res.status(404).json({ error: "Must supply movie Id and comment Id" });
    return;
  }

  try {
    let movie = await movieDataObj.getMovieById(req.params.movieId);

    let commentArray = movie["comments"];

    if (
      !commentArray ||
      !Array.isArray(commentArray) ||
      commentArray.length === 0
    ) {
      throw "Empty comment array";
    }

    let deleteComment = await commentDataObj.getCommentById(
      commentArray,
      req.params.commentId
    );

    commentArray = await commentDataObj.deleteComment(
      commentArray,
      deleteComment["_id"]
    );

    let updateMovie = await movieDataObj.updateMovie(
      req.params.movieId,
      movie["title"],
      movie["cast"],
      movie["info"],
      movie["plot"],
      movie["rating"],
      commentArray
    );

    res.json(updateMovie);
  } catch (error) {
    res.status(404).json({ error: "Cannot delete Comment." });
    return;
  }
});

module.exports = router;
