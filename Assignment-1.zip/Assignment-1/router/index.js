const movie = require("./movieRoute");

const constructorMethod = (app) => {
  app.use("/api/movies", movie);

  app.use("*", (req, res) => {
    res.sendStatus(404);
  });
};
5;

module.exports = constructorMethod;
