import React from 'react';
import './App.css';
import Error from './components/Error';
import Home from './components/Home';
import ListingPage from './components/ListingPage';
import DetailsPage from './components/DetailsPage'
import { BrowserRouter as Router, Route, Link, Switch} from 'react-router-dom';

function App() {
  return (
    <Router>
			<div className='App'>
        <header className='App-header'>
					<h1 className='App-title'>......Welcome to the Marvel Comics......</h1>
					<Link className = 'App-link' to='/'>Home	</Link>
          <Link className = 'App-link' to='/characters/page/0'>Character	</Link>
          <Link className = 'App-link' to='/comics/page/0'>Comic</Link>
          <Link className = 'App-link' to='/series/page/0'>Series</Link>
				</header>
				<br />
				<br />
        <Switch>      
        <Route  path='/' exact component={Home} />
		 			<Route  path='/characters/page/:page' exact component={ListingPage} /> 
          <Route  path='/characters/:id' exact component={DetailsPage} />
         <Route  path='/comics/page/:page' exact component={ListingPage} />
          <Route  path='/comics/:id' exact component={DetailsPage} />
           <Route  path='/series/page/:page' exact component={ListingPage} />
          <Route  path='/series/:id' exact component={DetailsPage} /> 
          <Route path='*' exact component={Error} status={404} />
        </Switch>		   		
			</div>
		</Router>
    
  );
};

export default App;
