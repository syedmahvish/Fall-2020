import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import noImage from '../Resource/noimage.jpeg';
import { Grid,makeStyles} from '@material-ui/core';
import '../App.css';
import Error from './Error';
import SearchItem from './Search';


const md5 = require('blueimp-md5');

const useStyles = makeStyles({
	card: {
		maxWidth: 250,
		height: 'auto',
		marginLeft: 'auto',
		marginRight: 'auto',
		borderRadius: 5,
		border: '1px solid #1e8678',
		boxShadow: '0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22);'
	},
	titleHead: {
		borderBottom: '1px solid #1e8678',
		fontWeight: 'bold'
	},
	grid: {
		flexGrow: 1,
		flexDirection: 'row'
	},
	media: {
		height: '100%',
		width: '100%'
	},
	button: {
		color: '#1e8678',
		fontWeight: 'bold',
		fontSize: 12
	},
	pagelink: {
		backgroundColor : "#ffffff",
		borderRadius: "3px",
		color: "#178577",
		margin: "5px"
	}
});


const ListingPage = (props) => {

let pageName = props.match.path.split("/")[1];   

let searchstartWith = "name"
if(pageName !== "characters"){
    searchstartWith = "title"
}

const classes = useStyles();
let card = null
const regex = /(<([^>]+)>)/gi;
const numberRegex =   /^\d+$/gi;

let currentPageNumber = -1;
let pageNumber = props.match.params.page

if (pageNumber.match(numberRegex) && pageNumber.length >= 1) {
	currentPageNumber = parseInt(props.match.params.page);
}

let nextPage = `/${pageName}/page/${currentPageNumber + 1}`;
let prevPage = `/${pageName}/page/${currentPageNumber - 1}`;

const [characterdata, setCharacterData] = useState({ data: null, loading: true });
const [errorData, setErrorData] = useState({ data: false});
const [searchData, setSearchData ] = useState(); 
const [searchTerm, setSearchTerm ] = useState();
    
const publickey = "d3cc0e84e1c532ea24288283c4ed2cfb";
const privatekey = "fc7173c9a449bee0ec7657c2254bcfdf3a23cf3d";
const ts = new Date().getTime();
const stringToHash = ts + privatekey + publickey;
const hash = md5(stringToHash);
const baseUrl = `https://gateway.marvel.com:443/v1/public/${pageName}?limit=100`;
const url = baseUrl + '&offset=' + (100 * currentPageNumber + 1) +'&ts=' + ts + '&apikey=' + publickey + '&hash=' + hash;

const baseSearchUrl = `https://gateway.marvel.com:443/v1/public/${pageName}?${searchstartWith}StartsWith=`;
const searchUrl = baseSearchUrl + searchTerm +'&ts=' + ts + '&apikey=' + publickey + '&hash=' + hash;

const useAxios = (url) => { 
    useEffect(() => {
		setSearchData({ data: null});
		setCharacterData((data) => ({ data: data, loading: true }));
		axios.get(url).then(({data}) => {
			setCharacterData({ data: data.data.results, loading: false });
		})
		.catch(err => {
		setErrorData({ data: true});     
		})
	   }, [pageName , currentPageNumber]);
    return characterdata;
  };

  const useSearchAxios = (searchUrl) => { 
    useEffect(() => {
		setSearchData((data) => ({ data: data}));
		axios.get(searchUrl).then(({data}) => {
			setSearchData({ data: data.data});
		})
	   }, [searchTerm]);
    return searchData;
  };

    
	let {resultdata, loading} = useAxios(url);
	useSearchAxios(searchUrl);
		
	const searchValue = async (value) => {
		setSearchTerm(value);
	};

	const buildCard = (character) => {
		return (
			<Grid item xs={12} sm={6} md={4} lg={3} xl={2} key={character.id}>
			<div class={classes.card}>
			<img className={classes.media} src={character.thumbnail && character.thumbnail.path ? `${character.thumbnail.path + "." + character.thumbnail.extension}` : noImage} alt={character.thumbnail}></img>
			<div class={classes.container}>
			<Link className={classes.pagelink} aria-label={classes.pagelink} to={`/${pageName}/${character.id}`}>{character.name ? character.name : character.title}</Link>	
			<p className={classes.titleHead}> {character.description ? character.description.replace(regex, '').substring(0, 139) + '...' : 'No Summary'}</p>
			<Link className={classes.pagelink} to={`/${pageName}/${character.id}`}>More info</Link>
			</div>
		   </div>
		   </Grid>              
		);
    };  

	if (searchTerm && searchData && searchData.data) {
		let mapdata = []
        mapdata = searchData.data.results
		card = mapdata && mapdata.map( (character) => {
			return buildCard(character);
		})
	}else if(!loading && characterdata && Object.keys(characterdata.data).length > 0 && currentPageNumber >= 0) {
        let mapdata = characterdata.data
        card = mapdata && mapdata.map((character) => {
             return buildCard(character);
          })
	}else if(errorData.data || isNaN(currentPageNumber) || (!loading && Object.keys(characterdata.data).length === 0)){
		return (
		  <div> <Error/> </div>
		);
   }
	
   if(loading){
	 return(
		<div>
		<h2>Loading....</h2>
		</div>
	 );  	
   }else{
            return (
                <div>
				 <SearchItem searchValue={searchValue} />
                 <br />
				 <br />
                
				{currentPageNumber > 0 && Object.keys(characterdata.data).length >= 1? (
                  <Link className = {classes.pagelink} to={prevPage}>Previous</Link>
                ) : null}  

        
		        {currentPageNumber >= 0 && Object.keys(characterdata.data).length >= 100 ? (
                  <Link className = {classes.pagelink} to={nextPage}>Next</Link>
                ) : null}

                <br />
				<br />
                <br />
				<br />
                    
                    <Grid container className={classes.grid} spacing={5}>
                        {card}
                    </Grid>
                    
                </div>
                
			);
		  }
        };	

export default ListingPage;