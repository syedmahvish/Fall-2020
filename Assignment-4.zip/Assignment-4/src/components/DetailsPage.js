import React, { useState, useEffect } from 'react';
import axios from 'axios';
import noImage from '../Resource/noimage.jpeg';
import '../App.css';
import Error from './Error';

const md5 = require('blueimp-md5');

const DetailsPage = (props) => {

let pageName = props.match.path.split("/")[1];   

const regex = /(<([^>]+)>)/gi;
const numberRegex =   /^\d+$/gi;

let characterId = -1;
let id = props.match.params.id

if (id.match(numberRegex) && id.length >= 1) {
	characterId = parseInt(props.match.params.id);
}
    
const [characterdata, setCharacterData] = useState({ data: null, loading: true });
const [errorData, setErrorData] = useState({ data: false});
    
const publickey = "d3cc0e84e1c532ea24288283c4ed2cfb";
const privatekey = "fc7173c9a449bee0ec7657c2254bcfdf3a23cf3d";//"26950e27c514addee6d6f1b804cada900aafe88a";
const ts = new Date().getTime();
const stringToHash = ts + privatekey + publickey;
const hash = md5(stringToHash);
const baseUrl = `https://gateway.marvel.com:443/v1/public/${pageName}/${characterId}`;
const keyUrl = '?ts=' + ts + '&apikey=' + publickey + '&hash=' + hash;
const url =   baseUrl + keyUrl;

const useAxios =  (url) => {
     useEffect(() => {
          setCharacterData((data) => ({ data: data, loading: true }));
          axios.get(url).then(({data}) => {
          setCharacterData({ data: data.data.results, loading: false });
      })
      .catch(err => {
          setErrorData({ data: true});     
      })
    }, [characterId]);
    return characterdata;
  };


    let {resultdata, loading} =  useAxios(url);

    let completeDetails = null;
    let characterCreatorItems = null;
    let charcterComicItems = null;
    let charcterSeriesItems = null;
    let charcterStoryItems = null;
    let charcterEventsItems = null;
    let charcterURLItems = null;
    let charcterCharacterItems = null;

	if(!loading && characterdata.data){
        completeDetails = characterdata.data[0];
        // console.log(JSON.stringify(completeDetails))
        
        if(completeDetails.characters && completeDetails.characters.available > 0) {
            charcterCharacterItems = completeDetails.characters.items.map((item) =>
             <li key={item.name}>{item.name}</li>);
        }

        if(completeDetails.creators && completeDetails.creators.available > 0){
            characterCreatorItems = completeDetails.creators.items.map((item) =>
            <li key={item.name}>{item.name + " : " + item.role}</li>);
        }

        if(completeDetails.comics && completeDetails.comics.available > 0){
            charcterComicItems = completeDetails.comics.items.map((item) =>
            <li key={item.name}>{item.name}</li>);
        }

        if(completeDetails.series && completeDetails.series.available > 0){
            charcterSeriesItems = completeDetails.series.items.map((item) =>
            <li key={item.name}>{item.name}</li>);
        }

        if(completeDetails.stories && completeDetails.stories.available > 0){
            charcterStoryItems = completeDetails.stories.items.map((item) =>
            <li key={item.name}>{item.name}</li>);
        }

        if(completeDetails.events && completeDetails.events.available > 0){
            charcterEventsItems = completeDetails.events.items.map((item) =>
            <li key={item.name}>{item.name}</li>);
        }

        if(completeDetails.urls && completeDetails.urls.length > 0){
            charcterURLItems = completeDetails.urls.map((item) =>
            <li key={item.url}> {item.type + " : "} <a href = {item.url} > {item.url} </a></li>);
        }       
  }else if(errorData.data){
    return (
      <div> <Error/> </div>
    );
  }

   if(loading){
	 return(
		<div>
		<h2>Loading....</h2>
		</div>
	 );  	
   }else{
        return(
            <div>
                <p className="App-title">{completeDetails.name ? completeDetails.name : completeDetails.title}</p>
                <br></br>
                <img className="image-style" src={completeDetails.thumbnail && completeDetails.thumbnail.path ? `${completeDetails.thumbnail.path + "." + completeDetails.thumbnail.extension}` : noImage} alt=""></img>
                <div className="App-title">
                 {completeDetails.description ? completeDetails.description.replace(regex, '') : 'No Summary'}
                </div> 
                <h2>Start Year  </h2>
                <p className="App-title">{completeDetails.startYear ? completeDetails.startYear : "N/A"}</p>
                <h2>End Year  </h2>
                <p className="App-title">{completeDetails.endYear ? completeDetails.endYear : "N/A"}</p>
                <h2>Rating  </h2>
                <p className="App-title">{completeDetails.rating ? completeDetails.rating : "N/A"}</p>

                <h2>Series </h2>
                <p className="App-title">{completeDetails.series ? completeDetails.series.name : "N/A"} </p>

                <h2 className="App-title">Price: {completeDetails.prices ?  completeDetails.prices[0].price : "N/A"} </h2>

                <h2>Character </h2>
                {charcterCharacterItems ? <ul className="App-title">{charcterCharacterItems}</ul> : <p className="App-title"> N/A</p>}

                <h2>Comics </h2>
                {charcterComicItems ? <ul className="App-title">{charcterComicItems}</ul> : <p className="App-title">N/A</p>}
    
                <h2>Series </h2>
                {charcterSeriesItems ? <ul className="App-title">{charcterSeriesItems}</ul> : <p className="App-title">N/A</p>}
                
                <h2>Stories </h2>
                {charcterStoryItems ? <ul className="App-title">{charcterStoryItems}</ul> : <p className="App-title">N/A</p>}
               
                <h2>Creators </h2>
                {characterCreatorItems ? <ul className="App-title">{characterCreatorItems}</ul> : <p className="App-title"> N/A</p>}

                <h2>Events </h2>
                {charcterEventsItems ? <ul className="App-title">{charcterEventsItems}</ul> : <p className="App-title"> N/A</p>}
                
                <h2>Source </h2>
                {charcterURLItems ? <ul className="App-title">{charcterURLItems}</ul> : <p className="App-title">N/A</p>}
               
            </div>    

        );
        }
    }
  
export default DetailsPage;