import React from 'react';

const Home = () => {
	return ( 
		<div>
            <h1 className='App-title'>
            CREATE AWESOME STUFF WITH THE WORLD'S GREATEST COMIC API.
            </h1>    
			<p className='App-title'>           
            The Marvel Comics API allows developers everywhere to access information about Marvel's vast library of comics—from what's coming up, to 70 years ago.
			</p>
             <p>Checkout Marvel's Characters </p>
             <a className='button-3d' href="/characters/page/0">Character</a>

             <p>Checkout Marvel's Comics </p>
            <a className='button-3d' href="/comics/page/0">Comic</a> 
            
            <p>Checkout Marvel's Series </p>
            <a className='button-3d' href="/series/page/0">Series</a>

            
          
		</div>
	);
};

export default Home;