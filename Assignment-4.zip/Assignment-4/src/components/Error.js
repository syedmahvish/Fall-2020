
import React from 'react';

const Error = () => {
 return (
    			<div className="error-msg">
    				<h1>Page not found</h1>
    				<p>Sorry, there is nothing to see here.</p>
    				
    			</div>
        );
 };

export default Error;