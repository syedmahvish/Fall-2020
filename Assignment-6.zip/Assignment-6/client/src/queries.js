import {gql} from "@apollo/client"

const GET_ALL_UNSPLASH_POST = gql`
query getAllUnsplashImages($pageNum : Int) {
    unsplashImages(pageNum:$pageNum){
     id
     url
    description
    posterName
    binned
    userPosted
  }
}`

const GET_ALL_USER_POST = gql`
query getAllPost{
    userPostedImages{
      id
      url
      description
      posterName
      binned
      userPosted
    }
  }`

  const GET_ALL_BINNED_POST = gql`
  query getAllBinnedPost{
    binnedImages{
      id
      url
      description
      posterName
      binned
      userPosted
    }
  }`
  
  const ADD_POST = gql`
  mutation addPost($url : String!, $description: String, $posterName : String) {
  uploadImage(url:$url, description:$description, posterName:$posterName){
    id
    url
    description
    posterName
    binned
    userPosted
  }
}`

const EDIT_POST = gql`
mutation editPost($id :ID!, $url : String, $description: String, $posterName : String, $binned : Boolean, $userPosted : Boolean){
    updateImage(id :$id, url:$url, description:$description, posterName:$posterName, binned : $binned, userPosted : $userPosted){
      id
      url
      description
      posterName
      binned
      userPosted
    }
  }`

  const DELETE_POST = gql`
  mutation deletePost($id : ID!){
    deleteImage(id:$id){
       id
      url
      description
      posterName
      binned
      userPosted
    }
  }`


export default {
    GET_ALL_UNSPLASH_POST,
    GET_ALL_USER_POST,
    GET_ALL_BINNED_POST,
    ADD_POST,
    EDIT_POST,
    DELETE_POST
}