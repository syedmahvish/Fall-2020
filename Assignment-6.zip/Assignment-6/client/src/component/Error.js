import React from "react"
import './App.css';
function Error(){
    return(
        <div className="error"> 
           <br/> <br/> <br/> 
           Error occured : Something went wrong !!!!!!!!!!!
        </div>
    )
        
    
 }
 
 export default Error