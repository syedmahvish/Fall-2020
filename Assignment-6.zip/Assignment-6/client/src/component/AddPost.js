import React, { useState } from 'react';
import './App.css';
import ReactModal from 'react-modal';
import { useQuery, useMutation } from '@apollo/client';
import queries from '../queries';

//For react-modal
ReactModal.setAppElement('#root');
const customStyles = {
  content: {
    top: '50%',
    left: '50%',
    right: 'auto',
    bottom: 'auto',
    marginRight: '-50%',
    transform: 'translate(-50%, -50%)',
    width: '50%',
    border: '1px solid #28547a',
    borderRadius: '4px'
  },

  formgroup:{
    width: '80%',
    borderRadius: '4px',
    textalign: 'center',
    marginLeft: '10%',
    background: '#D3D3D3',
    height : '25px'
  },
  formLabel:{
    margin: '0 auto',
    display: 'table',
    textalign: 'center',
  },
  formButton:{
    padding: '0.4rem 0.8rem',
    background: '#FF0000',
    borderradius: '3px',
    color: 'white',
    display: 'table',
    margin: '0 auto',
    width:'25%'
  },
  formTittle:{
    textDecoration: 'underline',
    display: 'table',
    margin: '0 auto',
  },
  formClose:{
    right:'5px',
    top:'5px',
    position:'absolute'
}
};

function AddPost(props) {
  const [showAddModal, setShowAddModal] = useState(props.isOpen);

  const { data } = useQuery(queries.GET_ALL_USER_POST);

  const [addPost] = useMutation(queries.ADD_POST, {
    refetchQueries: [{ query: queries.GET_ALL_USER_POST}],
    awaitRefetchQueries: true,
  });

  const handleCloseAddModal = () => {
    setShowAddModal(true);
    props.handleClose(false);
  };
 
  let body = null
  if (data) {
    let url;
    let description;
    let posterName;  
    body = (
      <form
        className="form"
        id="add-Post"
        onSubmit={(e) => {
          e.preventDefault();
          addPost({
            variables: {
              url: url.value,
              description: description.value,
              posterName: posterName.value
            }
          });
          url.value = '';
          description.value = '';
          posterName.value = '';
          setShowAddModal(false);
          alert('Post Added Successfully');
          props.handleClose();
        }}
      >
        <h1 style={customStyles.formTittle}> Create a Post </h1>  
        <div>
          <br/> <br/>
          <label style={customStyles.formLabel}>Image URL: </label> <br/> 
            <input style={customStyles.formgroup}
              ref={(node) => {
                url = node;
              }}
              required
              autoFocus={true}
            />
         
        </div>
        <br />
        <div>
          <label style={customStyles.formLabel}> Description: </label> <br/> 
            <input style={customStyles.formgroup}
              ref={(node) => {
                description = node;
              }}
            />
         
        </div>
        <br />

        <div>
          <label style={customStyles.formLabel}> Author Name:</label>  <br/>           
            <input style={customStyles.formgroup}
              ref={(node) => {
                posterName = node;
              }}
            />         
        </div>
        <br />
        <br />
        <button style={customStyles.formButton} type="submit">
          Submit
        </button>
      </form>
    );
  } 
  return (
    <div>
      <ReactModal
        name="AddPost"
        isOpen={showAddModal}
        contentLabel="AddPost"
        style={customStyles}
      >
        {body}
        <div>
        <button style={customStyles.formClose} onClick={handleCloseAddModal}>
          Close
        </button>
        </div>
      </ReactModal>  
    </div>
    
  );
}

export default AddPost;
