import React, {useState} from 'react';
import './App.css';
import { useQuery , useMutation} from '@apollo/client';
import queries from '../queries';
import Error from "./Error"
import AddPost from './AddPost';


function UserPost(props) {
  
  const [showAddModal, setShowAddModal] = useState(false);

  const { loading, error, data } = useQuery(queries.GET_ALL_USER_POST, {
    fetchPolicy: 'cache-and-network'
  });

  const[editPost] = useMutation(queries.EDIT_POST)

  const[deletePost] = useMutation(queries.DELETE_POST, {
    refetchQueries: [{ query: queries.GET_ALL_USER_POST}],
    awaitRefetchQueries: true,
  });


  const handleCloseModals = () => {
    setShowAddModal(false);
  };

  const handleOpenAddModal = () => {
    setShowAddModal(true);
  };

  if(loading){
    return <div>Loading</div>;
  }

  if(error){
      return <div> <Error/> </div>
  }
  
 
  if (data) {
    let userPostData  = data["userPostedImages"];

    return (
      <div class="col-12 col-xl-12 .col-lg-12 col-md-12 col-sm-12">
          <br/>
          <br/>
           <button className="add-post-button" onClick={handleOpenAddModal}> Upload a Post </button>
        {userPostData.map((post) => {
          return (
                    <div class="card" key={post.id}>
                       
                        <div class="card-body">
                            <h2 class="card-title"><br/><br/>
                            {post.description} : {post.posterName}
                            </h2>

                            <img class="card-img-top" src={post.url} alt="image1"></img>
                            <br/>
                            <br/>
                            <div class=".col-6 .col-xl-6 .col-lg-6 .col-md-6 .col-sm-6 .col-xs-6">
                            <button class="add-button" id={"add" + post.id} onClick={() => { 
                                 editPost(
                                     {
                                         variables : {
                                             id : post.id,
                                             binned : true
                                         }
                                     }
                                 )

                            }}>
                            Add to bin
                            </button>

                            <button class="cancel-button" id={"delete" + post.id} onClick={() => { 
                                 deletePost(
                                     {
                                         variables : {
                                             id : post.id
                                         }
                                     }
                                 )

                            }}>
                            Delete
                            </button>
                            </div>

                            <br/>
                            <br/>

                        </div>
                    </div>
               
          );
          
        })}
        {/*Add Post Modal */}
        {showAddModal && showAddModal &&(
          <AddPost
            isOpen={showAddModal}
            handleClose={handleCloseModals}
            modal="AddPost"
          />
        )}
        {

        }
      </div>
    );
  } 
}

export default UserPost;
