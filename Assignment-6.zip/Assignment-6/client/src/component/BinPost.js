import React from 'react';
import './App.css';
import { useMutation, useQuery } from '@apollo/client';
import queries from '../queries';
import Error from "./Error"

function BinPost() {
  
  const { loading, error, data } = useQuery(queries.GET_ALL_BINNED_POST, {
    fetchPolicy: 'cache-and-network'
  });
  const[editPost] = useMutation(queries.EDIT_POST)
  
  
  if (data) {
    let binnedData  = data["binnedImages"];

    return (
      <div class="col-12 col-xl-12 .col-lg-12 col-md-12">
        {binnedData.map((post) => {
          return (
            
                    <div class="card" key={post.id}>
                       
                        <div class="card-body">
                            <h2 class="card-title"><br/><br/>
                            {post.description} : {post.posterName}</h2>
                            <img class="card-img-top" src={post.url} alt="image1"></img>
                            <br/>
                            <br/>
                            <button className="button" id={post.id} onClick={() => {
                                editPost(
                                 {
                                     variables : {
                                         id : post.id,
                                         binned : false
                                     }
                                 }
                             )
                            }}
                             >
                             Remove from bin
                           </button>
                            <br/>
                            <br/>

                        </div>
                    </div>
               
          );
          
        })}
      </div>
    );
  } else if (loading) {
    return <div>Loading</div>;
  } else if (error) {
    return <div><Error/></div>;;
  }
}

export default BinPost;
