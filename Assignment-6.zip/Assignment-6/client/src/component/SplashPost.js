import React, { useState } from 'react';
import './App.css';
import { useQuery, useMutation } from '@apollo/client';
import queries from '../queries';
import Error from "./Error"


function SplashPost(props) {
  const[pageNumber, setPageNumber] = useState(1)

  const { loading, error, data } = useQuery(queries.GET_ALL_UNSPLASH_POST, {
    variables :{ pageNum : pageNumber},
    fetchPolicy: 'cache-and-network'
  });
  const[editPost] = useMutation(queries.EDIT_POST)

  if (loading) {
    return <div>Loading</div>;
  } 
  
  if (error) {
    return <div><Error/></div>;;
  }
  
  if (data) {
    let unsplashPostData  = data["unsplashImages"];
    
    return (
      <div class="col-12 col-xl-12 .col-lg-12 col-md-12">
        {unsplashPostData.map((unsplashPost) => {
          return (
            <div class="card" key={unsplashPost.id}>
            <div class="card-body">
            <h2 class="card-title"><br/><br/>
                {unsplashPost.description} : {unsplashPost.posterName}</h2>
            <img class="card-img-top" src={unsplashPost.url} alt="image1"></img>
            <br/><br/>
            <button className="button" id={unsplashPost.id}  onClick={() => {
                  editPost({
                            variables : {
                                id : unsplashPost.id,
                                binned : !unsplashPost.binned
                            }
                          })
            }}> {unsplashPost.binned ?  "Remove from bin" : "Add to bin"} </button>
            <br/><br/>
            </div>
            <br/> <br/> <br/>
            </div>  
          );
       })}
        <div> 
        <button className="more-post-button" id="MoreButton"  onClick={() => { 
           setPageNumber(pageNumber + 1)
        }}> More Images </button>
        </div>
    </div>
    );
  } 
}

export default SplashPost;
