import './App.css';
import {ApolloClient, ApolloProvider, HttpLink, InMemoryCache} from '@apollo/client'
import { NavLink, BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import BinPost from "./BinPost"
import UserPost from "./UserPost"
import AddPost from "./AddPost"
import Error from "./Error"
import SplashPost  from "./SplashPost"

const client = new ApolloClient({
  cache: new InMemoryCache(),
  link: new HttpLink({
    uri: 'http://localhost:4000'
  })
});

function App() {
  return (
    <ApolloProvider client={client}>
    <Router>
        <div class=".col-4 .col-xl-4 .col-lg-4 .col-md-4 .col-sm-4 .col-xs-4">
          <header className = "App-header">
            <h1 className = "App-title">Binterest </h1>
            <nav>
             <NavLink className="navlink" to="/my-bin">
                my bin
              </NavLink>
              <NavLink className="navlink" to="/">
                images
              </NavLink>
              <NavLink className="navlink" to="/my-posts">
                my posts
              </NavLink>              
            </nav>
          </header>
          <Switch>
          <Route exact path="/" exact component={SplashPost} />
          <Route path="/my-posts" component={UserPost} />
          <Route path="/my-bin" component={BinPost}/>
          <Route exact path="/new-post" exact component={AddPost} />
          <Route exact path="*" exact component={Error} />
          </Switch>
        </div>
      </Router>
    </ApolloProvider>
  );
}

export default App;
