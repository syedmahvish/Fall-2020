const axios = require('axios')
const {ApolloServer, gql} = require("apollo-server")
const loadash = require("lodash")
const uuid = require("uuid")
const fetch = require('node-fetch');
global.fetch = fetch;
const Unsplash = require('unsplash-js').default;
const toJson = require('unsplash-js').toJson;

const unsplash = new Unsplash({ accessKey: "TPFAPzqu4-niGuDzCRWTBPpirmgXtRHmFULC3qkRw3g" });

const bluebird = require("bluebird");
const redis = require("redis");
const client = redis.createClient();

bluebird.promisifyAll(redis.RedisClient.prototype);
bluebird.promisifyAll(redis.Multi.prototype);



const typeDefs = gql`
type ImagePost {
    id: ID
    url: String
    posterName: String
    description: String
    userPosted: Boolean
    binned: Boolean
},

type Query{
    unsplashImages(pageNum: Int) : [ImagePost]
    binnedImages : [ImagePost]
    userPostedImages : [ImagePost]
}

type Mutation{
    uploadImage(url: String!, description: String, posterName: String) : ImagePost
    updateImage(id: ID!, url: String, posterName: String, description: String, userPosted: Boolean, binned: Boolean) : ImagePost
    deleteImage(id: ID!) : ImagePost
}
`;


const resolvers = {
    Query: {
           unsplashImages: async (_, args) => {
            console.log(`page = ${args.pageNum}`)
            let unsplashImageArray = await axios.get(`https://api.unsplash.com/photos?page=${args.pageNum}&client_id=TPFAPzqu4-niGuDzCRWTBPpirmgXtRHmFULC3qkRw3g`)
            let allPostString  = await client.getAsync("allCachePost")
            let cacheImageArray =  JSON.parse(allPostString)

            let imagePostArray = Array()
            unsplashImageArray.data.map((element) => {
                let imageUrl = element["urls"]
                let user = element["user"]

                let isImageBinned =  cacheImageArray.filter(function (item) {
                                        if(item) return item.id === element["id"];
                                    })[0];
               
                let image = {
                    id : element["id"] === null ? uuid_V4() : element["id"],
                    url : imageUrl["regular"] === null ? null : imageUrl["regular"],
                    description : element["description"] === null ? null : element["description"],
                    posterName : user["name"] === null ? null : user["name"],
                    userPosted : false,
                    binned : isImageBinned ? true : false
                 }

                 imagePostArray.push(image) 
            })
            return imagePostArray;
            
        },
       
        binnedImages: async () => {
            let allPostString  = await client.getAsync("allCachePost")
            let binnedArray =  JSON.parse(allPostString)
            return binnedArray.filter(function (item) {
                if(item)
                    return item.binned === true;
            });           
        },

        userPostedImages: async () => {
            let allPostString  = await client.getAsync("allCachePost")
            let allPostArray =  JSON.parse(allPostString)
            return allPostArray.filter(function (item) {
                if(item)
                    return item.binned === false;
            });
        }


    },

    Mutation:{
        uploadImage: async (_, args) => {

            let allPostString  = await client.getAsync("allCachePost") 
            let userArray = new Array()
            if(allPostString)
                userArray = JSON.parse(allPostString)
            
            let image = {
               id : uuid.v4(),
               url : args.url,
               description : args.description,
               posterName : args.posterName,
               userPosted : true,
               binned : false
            }
          
            userArray.push(image)               
            client.setAsync("allCachePost", JSON.stringify(userArray))
            return image
        },

        updateImage: async (_, args) => {
            
            let allPostString  = await client.getAsync("allCachePost") 
            let userArray = new Array()
            if(allPostString)              
                userArray = JSON.parse(allPostString)

            let image = userArray.filter(function (item) {
                if(item)
                    return item.id === args.id;
                })[0];

            
            // all user post and splash post that are cached 
            // if user post and remove from bin , then update bin value and update cache
            // if splash post and remove from bin, then update bin = false and remove from cache

            if(image && image.id === args.id){
                    image.binned = args.binned  
                    
                    loadash.remove(userArray , image)
                    if(image.userPosted)   
                        userArray.push(image)
                    await client.setAsync("allCachePost", JSON.stringify(userArray));   
            }
            //if image from splash added to bin then cache
            else if(!image && !args.userPosted && args.binned){
                    //get image data
                    let rawData = await axios.get(`https://api.unsplash.com/photos/${args.id}?client_id=TPFAPzqu4-niGuDzCRWTBPpirmgXtRHmFULC3qkRw3g`)
                    let element =  rawData.data
                    let imageUrl = element["urls"]
                    let user = element["user"]
                   
                    image = {
                        id : element["id"] === null ? uuid_V4() : element["id"],
                        url : imageUrl["regular"] === null ? null : imageUrl["regular"],
                        description : element["description"] === null ? null : element["description"],
                        posterName : user["name"] === null ? null : user["name"],
                        userPosted : false,
                        binned : args.binned
                     }
    
                    userArray.push(image)                       
                    await client.setAsync("allCachePost", JSON.stringify(userArray));                           
            }
            
            return image           
        }, 

        deleteImage: async (_, args) => {
            let allPostString  = await client.getAsync("allCachePost") 
            let userArray = new Array()           
            if(allPostString)                
                userArray = JSON.parse(allPostString)

            let image = userArray.filter(function (item) {
                if(item)
                    return item.id === args.id;
                })[0];
            if(image)
                loadash.remove(userArray , image)

            await client.setAsync("allCachePost", JSON.stringify(userArray));
            return image                          
        } 
    }

};

const server = new ApolloServer({ typeDefs, resolvers });

server.listen().then(({ url }) => {
  console.log(`🚀  Server ready at ${url} 🚀`);
});