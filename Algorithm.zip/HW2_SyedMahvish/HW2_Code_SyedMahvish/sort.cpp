#include <cstdio>
#include <cstdlib>

#include "sort.h"
#include <iostream>
#include <list>
using namespace std;

/* 
 * HW 2 part
 */
int string_compare(char *s1, char *s2)
{
  /*
 * We assume that s1 and s2 are non-null pointers
 */
  int i;

  i = 0;
  while ((s1[i] != 0) && (s2[i] != 0) && (s1[i] == s2[i]))
    i++;

  if (s1[i] == s2[i])
    return 0;
  else
  {
    if (s1[i] < s2[i])
      return -1;
    else
      return 1;
  }
} /*>>>*/

/**
 * This method compares two given character s1 and s2, 
 * return int as 
 * 0 : if both are equal, 1
 * 1 : s2 > s1
 * -1 : s2 < s1
*/

int string_compare_char(char s1, char s2)
{
  /*
 * We assume that s1 and s2 are non-null pointers
 */

  if (s1 == s2)
    return 0;
  else
  {
    if (s1 < s2)
      return -1;
    else
      return 1;
  }
}

void insertion_sort(char **A, int l, int r)
{
  int i;
  char *key;

  for (int j = l + 1; j <= r; j++)
  {
    key = A[j];
    i = j - 1;

    while ((i >= l) && (string_compare(A[i], key) > 0))
    {
      A[i + 1] = A[i];
      i = i - 1;
    }

    A[i + 1] = key;
  }
}

/***
 * This method compares perform insertion sort on string for given position d.
*/
void insertion_sort_digit(char **A, int *A_len, int l, int r, int d)
{
  int i;
  char *key;
  char key_char = '0';
  int len;

  for (int j = l + 1; j < r; j++)
  {
    key_char = '0';
    if (A_len[j] >= d)
      key_char = A[j][d];

    key = A[j];
    len = A_len[j];
    i = j - 1;

    while ((i >= l) && A_len[i] >= d && (string_compare_char(A[i][d], key_char) > 0))
    {
      A[i + 1] = A[i];
      A_len[i + 1] = A_len[i];
      i = i - 1;
    }

    A[i + 1] = key;
    A_len[i + 1] = len;
  }
}

/***
 * This method compares perform counting sort on string for given position d.
*/
void counting_sort_digit(char **A, int *A_len, char **B, int *B_len, int n, int d)
{
  list<char *> itemArray[27];
  list<int> lenArray[27];

  int index = 0;

  for (int i = 0; i < n; i++)
  {
    index = 0;
    if (A_len[i] >= d)
    {
      int ascii_value = (int)A[i][d - 1];
      index = ascii_value - 97;
      index = index + 1;
    }
    itemArray[index].push_back(A[i]);
    lenArray[index].push_back(A_len[i]);
  }

  int count = 0;
  for (int j = 0; j <= 26; j++)
  {
    while (!itemArray[j].empty() && !lenArray[j].empty())
    {
      B[count] = *(itemArray[j].begin());
      B_len[count] = *(lenArray[j].begin());
      itemArray[j].erase(itemArray[j].begin());
      lenArray[j].erase(lenArray[j].begin());
      count++;
    }
  }

  for (int i = 0; i < n; i++)
  {
    A[i] = B[i];
    A_len[i] = B_len[i];
  }
}

/***
 * This method calls insertion sort to perform radix sort on every digit of string.
*/
void radix_sort_is(char **A, int *A_len, int n, int m)
{
  while (m >= 0)
  {
    insertion_sort_digit(A, A_len, 0, n, m);
    m--;
  }
}

/***
 * This method calls counting sort to perform radix sort on every digit of string.
*/
void radix_sort_cs(char **A, int *A_len, int n, int m)
{
  char **B;
  int *B_len;

  int i = 0;
  while (m > 0)
  {
    B = new char *[n];
    B_len = new int[n];
    counting_sort_digit(A, A_len, B, B_len, n, m);
    m--;

    delete[] B;
    delete[] B_len;
  }
}

/*
 * Simple function to check that our sorting algorithm did work
 * -> problem, if we find position, where the (i-1)-th element is 
 *    greater than the i-th element.
 */
bool check_sorted(char **A, int l, int r)
{
  for (int i = l + 1; i < r; i++)
  {
    if (string_compare(A[i - 1], A[i]) > 0)
      return false;
  }

  return true;
}
