#include <cstdio>
#include <cstdlib>
#include <iostream>

#include "sort.h"

int ivector_length(int *v, int n)
{
  int sum;

  sum = 0;
  for (int i = 0; i < n; i++)
    sum += (v[i] < 0) ? -v[i] : v[i];

  return sum;
}

/*
 * insertion sort
 */
void insertion_sort(int **A, int n, int l, int r)
{
  int i;
  int *key;

  for (int j = l + 1; j <= r; j++)
  {
    key = A[j];
    i = j - 1;

    while ((i >= l) && (ivector_length(A[i], n) > ivector_length(key, n)))
    {
      A[i + 1] = A[i];
      i = i - 1;
    }

    A[i + 1] = key;
  }
}

/*
*   TO IMPLEMENT: Improved Insertion Sort for problem 1.
*/
void insertion_sort_im(int **A, int n, int l, int r)
{
}

/*
*   TO IMPLEMENT: Improved Merge Sort for problem 2.

This function first convert n dimension array into one dimension Array(singleArray)
Then calls "divide_sort" : which divide array into subarray then sort them and then merge.
*/
void merge_sort(int **A, int n, int p, int r)
{
  //Calculate total size of given input array
  int total_size = (r + 1) * n;

  int k = 0;

  //initialize one dimension array
  int *singleArray = new int[total_size];

  //copy n dimension array i.e A into single array
  for (int i = 0; i <= r; i++)
    for (int j = 0; j < n; j++)
      singleArray[k++] = A[i][j];

  // perform merge sort on one dimension array i.e singleArray
  divide_sort(singleArray, p, total_size);

  // copy result into given input Array i.e A
  k = 0;
  for (int i = 0; i <= r; i++)
    for (int j = 0; j < n; j++)
      A[i][j] = singleArray[k++];
}

/*** 
 * This function merge back sorted array
*/

void merge(int *A, int first, int middle, int last)
{
  int firstArraySize = middle - first + 1;
  int lastArraySize = last - middle;

  //Create left and right subarray to store sub array
  int *leftArray = new int[firstArraySize];
  int *rightArray = new int[lastArraySize];

  //copy first half of given array into left subarray
  for (int i = 0; i < firstArraySize; i++)
    leftArray[i] = A[first + i];

  //copy second half of given array into right subarray
  for (int i = 0; i < lastArraySize; i++)
    rightArray[i] = A[middle + 1 + i];

  int i = 0;     // Initial index of first subarray
  int j = 0;     // Initial index of second subarray
  int k = first; // Initial index of merged subarray

  //check if left subarray value <= right subarray, copy left subarray value into resulting merged array i.e A
  //and increment left subarray pointer
  //else vice versa
  while (i < firstArraySize && j < lastArraySize)
  {
    if (leftArray[i] <= rightArray[j])
    {
      A[k] = leftArray[i];
      i++;
    }
    else
    {

      A[k] = rightArray[j];
      j++;
    }
    k++;
  }

  //copy remaining left subarray into result merged array i.e A
  while (i < firstArraySize)
  {
    A[k] = leftArray[i];
    i++;
    k++;
  }

  //copy remaining right subarray into result merged array i.e A
  while (j < lastArraySize)
  {
    A[k] = rightArray[j];
    j++;
    k++;
  }
}

/***
 * This function recursively calls itself until array contains only one value.
 * Then it calls merge function which sort subarrays and create result as merged array.
*/

void divide_sort(int *singleArray, int first, int last)
{
  if (first < last)
  {

    int middle = first + (last - first) / 2;
    //recursively calls itself until each subarray i.e singleArray contains only one value
    divide_sort(singleArray, first, middle);
    divide_sort(singleArray, middle + 1, last);

    // calls merge function that compares and sort singleArray and form sorted merged array.
    merge(singleArray, first, middle, last);
  }
}

/*
 * Simple function to check that our sorting algorithm did work
 * -> problem, if we find position, where the (i-1)-th element is 
 *    greater than the i-th element.
 */
bool check_sorted(int **A, int n, int l, int r)
{
  for (int i = l + 1; i <= r; i++)
  {
    if (ivector_length(A[i - 1], n) > ivector_length(A[i], n))
      return false;
  }
  return true;
}

/*
 * generate sorted/reverse/random arrays of type hw1type
 */
int **create_ivector(int n, int m)
{
  int **iv_array;

  iv_array = new int *[m];
  for (int i = 0; i < m; i++)
    iv_array[i] = new int[n];

  return iv_array;
}

void remove_ivector(int **iv_array, int m)
{
  for (int i = 0; i < m; i++)
    delete[] iv_array[i];
  delete[] iv_array;
}

int **create_sorted_ivector(int n, int m)
{
  int **iv_array;

  iv_array = create_ivector(n, m);
  for (int i = 0; i < m; i++)
    for (int j = 0; j < n; j++)
      iv_array[i][j] = (i + j) / n;

  return iv_array;
}

int **create_reverse_sorted_ivector(int n, int m)
{
  int **iv_array;

  iv_array = create_ivector(n, m);
  for (int i = 0; i < m; i++)
    for (int j = 0; j < n; j++)
      iv_array[i][j] = ((m - i) + j) / n;

  return iv_array;
}

int **create_random_ivector(int n, int m, bool small)
{
  random_generator rg;
  int **iv_array;

  iv_array = create_ivector(n, m);
  for (int i = 0; i < m; i++)
    for (int j = 0; j < n; j++)
    {
      rg >> iv_array[i][j];
      if (small)
        iv_array[i][j] %= 100;
      else
        iv_array[i][j] %= 65536;
    }

  return iv_array;
}
