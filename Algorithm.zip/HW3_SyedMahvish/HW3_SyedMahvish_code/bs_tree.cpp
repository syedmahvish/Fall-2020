
#include "bs_tree.h"
#include <list>
#include <iostream>

using namespace std;

/*
 * constructor/destructor
 */
bs_tree::bs_tree()
{
  /*<<<*/
  /*
 * create T_nil element
 */
  T_nil = new bs_tree_node();
  T_nil->p = T_nil;
  T_nil->left = T_nil;
  T_nil->right = T_nil;

  /*
 * root of rb tree
 */
  T_root = T_nil;
} /*>>>*/

bs_tree::~bs_tree()
{
  remove_all(T_root);

  delete T_nil;
}

void bs_tree::insert(int key, bs_tree_i_info &t_info)
{
  /***
   * wrapper around insert
   * inserts node
  */

  // check if key present in tree with isNodePresent(), if true increment duplicate counter.
  // else insert key binary tree.
  bs_tree_node *z;
  z = new bs_tree_node;
  z->key = key;

  insert(z, t_info);
}

// /***
//  * This method will return true if value already present in tree else false
// */
// bool bs_tree::isNodePresent(int key, bs_tree_node *root)
// {
//   if (root == T_nil)
//     return false;

//   if (root->key == key)
//     return true;

//   // if node present no need to go for further check
//   bool nodePresent1 = isNodePresent(key, root->left);
//   if (nodePresent1)
//     return true;

//   return isNodePresent(key, root->right);
// }

void bs_tree::insert(bs_tree_node *z, bs_tree_i_info &t_info)
{ /*<<<*/
  /*
 * binary tree type insert 
 * -> search position, insert new node
 * -> fix properties after insert
 */
  bs_tree_node *x;
  bs_tree_node *y;

  y = T_nil;
  x = T_root;
  while (x != T_nil)
  {
    y = x;

    if (z->key < x->key)
      x = x->left;
    else if (z->key > x->key)
      x = x->right;
    else
    {
      t_info.i_duplicate = t_info.i_duplicate + 1;
      return;
    }
  }

  z->p = y;
  if (y == T_nil)
    T_root = z;
  else
  {
    if (z->key < y->key)
      y->left = z;
    else
      y->right = z;
  }

  z->left = T_nil;
  z->right = T_nil;
}

// TODO: modified inorder tree walk method to save the
// sorted numbers in the first argument: int* array.
// question 2
int bs_tree::convert(int *array, int n)
{
  bs_tree_node *root = T_root;
  int initial = 0;
  int &count = initial;
  inorder_output_modify(array, root, count);
  return count;
}

void bs_tree::inorder_output_modify(int *array, bs_tree_node *x, int &count)
{ /*<<<*/
  /*
 * This method will perform in order walk through binary tree
 * Store value in array.
 * Use count to keep track of array index.
 */
  if (x != T_nil)
  {
    inorder_output_modify(array, x->left, count);
    array[count] = x->key;
    count = count + 1;
    inorder_output_modify(array, x->right, count);
  }
} /*>>>*/

void bs_tree::remove_all(bs_tree_node *x)
{ /*<<<*/
  /*
 * recursively remove all tree elements
 */
  if (x != T_nil)
  {
    remove_all(x->left);
    remove_all(x->right);

    delete x;
  }
}
