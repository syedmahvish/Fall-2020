#include "graph.h"
#include <iostream>
#include <queue>
#include <stack>
#include <set>

/***
 * Initialize graph with number of nodes.
 * Check if number of nodes > 0
*/
Graph::Graph(int n)
{
    if (n > 0)
    {
        nodes = n;
        matrix = new int *[nodes];

        for (int i = 0; i < nodes; i++)
        {
            matrix[i] = new int[nodes];
            for (int j = 0; j < nodes; j++)
            {
                matrix[i][j] = 0;
            }
        }
    }
    else
    {
        cout << "Invalid number of nodes. It should be greater than zero." << endl;
        return;
    }
}

/***
 * Initialize graph with adjacent matrix and number of nodes.
 * Check if number of nodes > 0
*/
Graph::Graph(int **adj, int n)
{
    if (n > 0)
    {
        nodes = n;
        matrix = new int *[nodes];
        for (int i = 0; i < nodes; i++)
        {
            matrix[i] = new int[nodes];
            for (int j = 0; j < nodes; j++)
            {
                matrix[i][j] = adj[i][j];
            }
        }
    }
    else
    {
        cout << "Invalid number of nodes. It should be greater than zero." << endl;
        return;
    }
}

Graph::~Graph()
{
    for (int i = 0; i < nodes; i++)
        delete[] matrix[i];
    delete[] matrix;
}

/***
 * Set value of edge in graph.
 * Check if provided node is valid.
 * Node value must be >= 0.
*/
bool Graph::set_edge(int u, int v, int w)
{
    if (u < 0 || v < 0 || u > nodes - 1 || v > nodes - 1)
    {
        cout << "Invalid node value." << endl;
        return false;
    }
    matrix[u][v] = w;
    return true;
}

/***
 * Implementing bfs with given source node.
 * Check if source node has valid value. 
*/
void Graph::bfs(int source)
{
    if (source < 0 || source > nodes - 1)
    {
        cout << "Please enter a valid source to start bfs (should be greater than zero)" << endl;
        return;
    }
    set<int> *visited = new set<int>;

    cout << "--------------- BFS ------------ " << endl;
    cout << " Source : " << source << endl;
    bfs(source, visited);
}

/***
 * Implementing bfs helper function with given source node and set.
*/
void Graph::bfs(int source, set<int> *visited)
{
    queue<int> bfs_queue;
    visited->insert(source);
    bfs_queue.push(source);

    while (!bfs_queue.empty())
    {
        //get node and print it.
        int source_node = bfs_queue.front();
        cout << source_node << " ";
        bfs_queue.pop();

        //visit all adjacent node and push into queue
        for (int v = 0; v < nodes; v++)
        {
            if (matrix[source_node][v] > 0 && visited->count(v) == 0)
            {
                visited->insert(v);
                bfs_queue.push(v);
            }
        }
    }
    delete visited;
}

/***
 * Implementing dfs.
*/
void Graph::dfs()
{
    int source = 0;

    if (source < 0 || source > nodes - 1)
    {
        cout << "Please enter a valid source to start dfs (should be greater than zero)" << endl;
        return;
    }

    set<int> *visited = new set<int>;

    cout << "--------------- DFS ------------" << endl;
    cout << "Source : " << source << endl;

    dfs(source, visited);
    cout << endl;
    delete visited;
}

/***
 * Implementing dfs helper function with given source node and set.
*/
void Graph::dfs(int source, set<int> *visited)
{
    stack<int> dfs_stack;
    visited->insert(source);
    dfs_stack.push(source);

    while (!dfs_stack.empty())
    {
        //get node and print it.
        int source_node = dfs_stack.top();
        cout << source_node << " ";
        dfs_stack.pop();

        //visit all adjacent node and push into stack
        for (int v = 0; v < nodes; v++)
        {
            if (matrix[source_node][v] > 0 && visited->count(v) == 0)
            {
                visited->insert(v);
                dfs_stack.push(v);
            }
        }
    }
}
