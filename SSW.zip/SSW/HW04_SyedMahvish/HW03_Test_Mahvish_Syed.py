import unittest
from HW03_Mahvish_Syed import Fraction, FractionSimplify


class FTest(unittest.TestCase):

    
    def test_init(self) -> None:
        """This function test init method of fraction class.

        It also test ValueError Which occur if denominator is 0.
        """
        self.assertTrue(Fraction(1, 2))
        self.assertRaises(ValueError, FractionSimplify, 9,0)
        
   
    def test_str(self) -> None:
        """This function test str method of fraction class.

        It test if str method prints fraction in intendend way or not
        """
        f12 = Fraction(1, 2)
        self.assertTrue(str(f12) == '1/2')
        self.assertFalse(str(f12) == '0/2')

   
    def test_add(self) -> None:
        """This function test addition of two fraction method assertTrue() is
        used to validate addition with desired result.

        Returns : result of two fraction addition in form of fraction
        """
        f12 = FractionSimplify(1, 2)
        f44 = FractionSimplify(4, -4)
        f128 = FractionSimplify(12, 8)
        f32 = FractionSimplify(3, 2)

        self.assertTrue((f12.simplify() + f12.simplify()) == Fraction(1,1))
        self.assertTrue((f12.simplify() + f44.simplify()) == Fraction(-1, 2))
        self.assertTrue((f12.simplify() + f128.simplify()) == Fraction(2, 1))
        self.assertTrue((f12.simplify() + f32.simplify()) == Fraction(2, 1))

        self.assertFalse((f12.simplify() + f32.simplify()) == Fraction(83, 4))

        self.assertTrue((f12.simplify() + f44.simplify() + f32.simplify()) == Fraction(1, 1))

   
    def test_minus(self) -> None:
        """This function test subtraction of two fraction method assertTrue()
        is used to validate subtraction with desired result.

        Returns : result of two fraction subtraction in form of fraction
        """
        f12 = FractionSimplify(1, 2)
        f44 = FractionSimplify(4, 4)
        f128 = FractionSimplify(-12, 8)
        f32 = FractionSimplify(3, 2)

        self.assertTrue((f12.simplify() - f12.simplify()) == Fraction(0, 4))
        self.assertTrue((f44.simplify() - f12.simplify()) == Fraction(1, 2))
        self.assertTrue((f12.simplify() - f128.simplify()) == Fraction(2, 1))
        self.assertTrue((f12.simplify() - f32.simplify()) == Fraction(-1, 1))

        self.assertFalse((f12.simplify() - f32.simplify()) == Fraction(2, 2))
        
        self.assertTrue((f12.simplify() - f44.simplify() - f32.simplify()) == Fraction(-2, 1))

   
    
    def test_mul(self) -> None:
        """This function test multiplication of two fraction method
        assertTrue() is used to validate multiplication with desired result."""
        f12 = FractionSimplify(1, 2)
        f44 = FractionSimplify(4, 4)
        f128 = FractionSimplify(12, 8)
        f32 = FractionSimplify(-3, 2)
        
        f02 = FractionSimplify(0, 2)
        
        

        self.assertTrue((f12.simplify() * f12.simplify()) == Fraction(1, 4))
        self.assertTrue((f44.simplify() * f12.simplify()) == Fraction(1, 2))
        self.assertTrue((f12.simplify() * f128.simplify()) == Fraction(3, 4))
        self.assertTrue((f12.simplify() * f32.simplify()) == Fraction(-3, 4))
        
        self.assertTrue((f02.simplify() * f32.simplify()) == Fraction(0, 6))
        
        self.assertFalse((f12.simplify() * f32.simplify()) == Fraction(9, 99))
        
        self.assertTrue((f12.simplify() * f44.simplify() * f32.simplify()) == Fraction(-3, 4))

   
    def test_truediv(self) -> None:
        """This function test division of two fraction method assertTrue() is
        used to validate division with desired result."""
        f12 = FractionSimplify(1, 2)
        f44 = FractionSimplify(4, 4)
        f128 = FractionSimplify(12, 8)
        f32 = FractionSimplify(3, 2)

        self.assertTrue((f12.simplify() / f12.simplify()) == Fraction(1, 1))
        self.assertTrue((f44.simplify() / f12.simplify()) == Fraction(2, 1))
        self.assertTrue((f12.simplify() / f128.simplify()) == Fraction(1, 3))
        self.assertTrue((f12.simplify() / f32.simplify()) == Fraction(1, 3))

        self.assertFalse((f12.simplify() / f32.simplify()) == Fraction(3, -4))
        
        self.assertTrue((f12.simplify() / f44.simplify() / f32.simplify()) == Fraction(1, 3))

    
    def test_eq(self) -> bool:
        """This function test if two fraction are equal or not method
        assertTrue() is used to validate equality of fraction with desired
        output."""
        f12 = FractionSimplify(1, 2)
        f44 = FractionSimplify(4, 4)
        f23 = FractionSimplify(2.3, 4.0)

        self.assertTrue(f12.simplify() == f12.simplify())
        self.assertFalse(f44.simplify() == f12.simplify())
        
        self.assertTrue(f23.simplify() == f23.simplify())
        self.assertFalse(f23.simplify() == f12.simplify())
    
    
    def test_ne(self) -> None:
        """This function test if two fraction are equal or not method
        assertTrue() is used to validate non-equality of fraction with desired
        output."""
        f12 = FractionSimplify(1, 2)
        f44 = FractionSimplify(4, 4)
        f23 = FractionSimplify(2.3, 4.0)

        self.assertTrue(f44.simplify() != f12.simplify())
        self.assertFalse(f12.simplify() != f12.simplify())
        
        self.assertTrue(f23.simplify() != f12.simplify())
        self.assertFalse(f23.simplify() != f23.simplify())  
     
      
    def test_lt(self) -> None:
        """This function test if one fraction is less than other fraction or
        not method assertTrue() is used to validate one fraction is less than
        other fraction or not with desired output.""" 
        f12 = FractionSimplify(1, 2)
        f44 = FractionSimplify(4, 4)
        f23 = FractionSimplify(2.3, 4.0)

        self.assertTrue(f12.simplify() < f44.simplify())
        self.assertFalse(f12.simplify() < f12.simplify())
        
        self.assertTrue(f12.simplify() < f23.simplify())
        self.assertFalse(f23.simplify() < f23.simplify()) 
     
       
    def test_le(self) -> None:
        """This function test if one fraction is less or equal to other
        fraction or not method assertTrue() is used to validate one fraction is
        less or equal to other fraction or not with desired output."""
        f12 = FractionSimplify(1, 2)
        f44 = FractionSimplify(4, 4)
        f23 = FractionSimplify(2.3, 4.0)

        self.assertTrue(f12.simplify() <= f44.simplify())
        self.assertTrue(f12.simplify() <= f12.simplify())
        
        self.assertFalse(f44.simplify() <= f12.simplify())
        
        self.assertTrue(f12.simplify() <= f23.simplify())
        
    
    def test_gt(self) -> None:
        """This function test if one fraction is greater than other fraction or
        not method assertTrue() is used to validate one fraction is greater
        than other fraction or not with desired output."""
        f12 = FractionSimplify(1, 2)
        f44 = FractionSimplify(4, 4)
        f23 = FractionSimplify(2.3, 4.0)

        self.assertTrue(f44.simplify() > f12.simplify())
        self.assertTrue(f23.simplify() > f12.simplify())
        
        self.assertFalse(f12.simplify() > f12.simplify())
        
    
    def test_ge(self) -> None:
        """This function test if one fraction is greater than or equal to other
        fraction or not method assertTrue() is used to validate one fraction is
        greater than or equal to other fraction or not with desired output."""
        f12 = FractionSimplify(1, 2)
        f44 = FractionSimplify(4, 4)
        f23 = FractionSimplify(2.3, 4.0)

        self.assertTrue(f12.simplify() >= f12.simplify())
        self.assertTrue(f44.simplify() >= f12.simplify())
        self.assertTrue(f23.simplify() >= f12.simplify())
        
        self.assertFalse(f12.simplify() >= f44.simplify())   
            
        
       


if __name__ == '__main__':
    unittest.main()
