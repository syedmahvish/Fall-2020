import unittest
from HW04_Mahvish_Syed import count_vowels, find_last, my_enumerate

class CountVowelsTest(unittest.TestCase):  
    def test_count_vowels(self) -> None:      
        """testing count vowels for string."""
        self.assertEqual(count_vowels('hello world'), 3)
        self.assertEqual(count_vowels('HelLOO WOrld'), 4)
        self.assertEqual(count_vowels('HlL Wrld'), 0)
        self.assertNotEqual(count_vowels('thank YOU'), 0)
        
        self.assertRaises(ValueError,count_vowels,"")
        self.assertRaises(ValueError,count_vowels,None)
        self.assertRaises(ValueError,count_vowels,1234)
        self.assertRaises(ValueError,count_vowels,[])
        
class FindLastTest(unittest.TestCase):    
    def test_find_last(self) -> None:        
        """testing find_last."""
        self.assertEqual(find_last("p","Happy"),3)
        self.assertEqual(find_last("w","Happy"),None)
        self.assertEqual(find_last(33,[ 42, 33, 21, 34, 56, 33]),5)
        self.assertNotEqual(find_last(33,[ 42, 33, 21, 34, 56, 33]),1)
        self.assertEqual(find_last("cake",[ "apple","ball", "cake", "dog" , "cake" , "egg" , "cake" , "fan"]),6)

        self.assertRaises(ValueError,find_last,"",[])
        self.assertRaises(ValueError,find_last,None,[34,56,66])


class EnumerateTest(unittest.TestCase):   
    def test_enumerate_list(self) -> None:        
        """test my_enumerate by storing the results in a list."""
        self.assertTrue(list(my_enumerate(["apple","cat","ball","mat"])) == list(enumerate(["apple","cat","ball","mat"])))
        self.assertTrue(list(my_enumerate([1,2,3,4,5,77,23])) == list(enumerate([1,2,3,4,5,77,23])))
        self.assertTrue(list(my_enumerate(["hello"])) == list(enumerate(["hello"])))
        self.assertTrue(list(my_enumerate([{1:"one"}, {2 : "two"},{1:"three"}, {2 : "four"}])) == list(enumerate([{1:"one"}, {2 : "two"},{1:"three"}, {2 : "four"}])))

        self.assertRaises(ValueError,my_enumerate,"")
        self.assertRaises(ValueError,my_enumerate,None)
        self.assertRaises(ValueError,my_enumerate,[])
        
        
if __name__ == '__main__':    
    unittest.main(exit=False, verbosity=2)