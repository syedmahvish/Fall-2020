"""This program accepts two fractions from user in form of numerator and
denominator.

It performs calculation operation on given fractions like add,
subtract,multiply and divides. It also checks if two fractions are equal
or not.
"""

"""
  Class Fraction initialize fraction with numerator and denominator.
  It performs calculation operation on given fractions.
"""

class Fraction:

   

    def __init__(self, numerator: float, denominator: float) -> None:
         """This function initialize fraction with given numerator and
         denominator.

         If denominator is zero , it raise exception ValueError.
         numerator : numerator of fraction.
         denominator : denominator of fraction.
         Returns none.
         """
         self.numerator : float = numerator
         if denominator == 0 :
            raise ValueError("Denominator is zero")
         else:
            self.denominator: float = denominator

    

    def __add__(self, other: "Fraction") -> "Fraction":
       """ This function perform addition of two fraction
       self : current fraction
       other : another fraction
       Returns : result of two fraction addition in form of fraction
       """
       value1: float = self.numerator * other.denominator
       value2: float = other.numerator * self.denominator
       value3: float = self.denominator * other.denominator
       return Fraction(value1 + value2, value3)

    

    def __sub__(self, other: "Fraction") -> "Fraction":
       """
       This function perform subtraction of two fraction
       self : current fraction
       other : another fraction
       Returns : result of two fraction subtraction in form of fraction
       """
       value1: float = self.numerator * other.denominator
       value2: float = other.numerator * self.denominator
       value3: float = self.denominator * other.denominator
       return Fraction(value1 - value2, value3)

    

    def __mul__(self, other: "Fraction") -> "Fraction":
       """ This function perform multiplication of two fraction
       self : current fraction
       other : another fraction
       Returns : result of two fraction multiplication in form of fraction
       """
       value1: float = self.numerator * other.numerator
       value2: float = self.denominator * other.denominator
       return Fraction(value1, value2)


    def __truediv__(self, other: "Fraction") -> "Fraction":
        
       """
       This function perform division of two fraction
       self : current fraction
       other : another fraction
       Returns : result of two fraction division in form of fraction
       """
       value1: float = self.numerator * other.denominator
       value2: float = self.denominator * other.numerator
       return Fraction(value1, value2)


    def __eq__(self, other: "Fraction") -> bool:
        """This function checks if two fractions are equals or not."""
        return (self.numerator * other.denominator) == (self.denominator * other.numerator)

   
    def __ne__(self, other: "Fraction") -> bool:
        """This function checks if two fractions are equals or not."""
        return (self.numerator * other.denominator) != (self.denominator * other.numerator)

   

    def __lt__(self, other: "Fraction") -> bool:
        """This function checks if first fractions is less than  second."""
        return (self.numerator * other.denominator) < (self.denominator * other.numerator)


    def __le__(self, other: "Fraction") -> bool:
        """This function checks if first fractions is less than or equal to
        second."""
        return (self.numerator * other.denominator) <= (self.denominator * other.numerator)

   
    def __gt__(self, other: "Fraction") -> bool:
        """This function checks if first fractions is greater than  second."""
        return (self.numerator * other.denominator) > (self.denominator * other.numerator)


    def __ge__(self, other: "Fraction") -> bool:
        """This function checks if first fractions is greater than or equal to
        second."""
        return (self.numerator * other.denominator) >= (self.denominator * other.numerator)


    def calculate(self, other: "Fraction", operator: str) -> "Fraction":
        """This function perform calculation operation on two fraction based on
        given operator."""
        if(operator == "+"):
            return self.__add__(other)
        elif(operator == "-"):
            return self.__sub__(other)
        elif(operator == "*"):
            return self.__mul__(other)
        elif(operator == "/"):
            return self.__truediv__(other)


    def checkEquality(self, other: "Fraction", operator: str) -> bool:
        """This function perform checks equality  on two fraction based on
        given equality operator."""
        if(operator == "=="):
            return self.__eq__(other)
        elif(operator == "!="):
            return self.__ne__(other)
        elif(operator == "<"):
            return self.__lt__(other)
        elif(operator == "<="):
            return self.__le__(other)
        elif(operator == ">"):
            return self.__gt__(other)
        elif(operator == ">="):
            return self.__ge__(other)

    
    def __str__(self) -> str:
        """This function display fraction in form of string."""
        return f"{self.numerator}/{self.denominator}"




class Parameter:

    def acceptInput(self, fracNum: int, fracPart: str) -> float:
        while True:   
            value : float = input(f"Enter fraction {fracNum} {fracPart} : ")
            try:
                return float(value)
            except ValueError:
                print(f"given value {value} is not a number")

   
    def getFraction(self, fracNum: int) -> "Fraction":
        numerator: float = self.acceptInput(fracNum, "numerator")
        denominator: float = self.acceptInput(fracNum, "denominator")
        return Fraction(numerator, denominator)

   
    def acceptOperator(self) -> str:
        operator: str = input(
            f"Operation (+, -, *, /, ==, != , <, <= , > , >=): ")
        while True:
            if operator in ['+', '-', '*', '/', '==', '!=', '<', '<=', '>', '>=']:
                return operator
            else:
                print(f"given value {operator} is not a valid operator")
                operator = input(
                    f"Operation (+, -, *, /, ==, != , <, <= , > , >=): ")




class FractionSimplify(Fraction):
    
    def simplify(self) -> "Fraction":
        """This method simplifies fraction by finding greatest common factor
        and dividing numerator and denominator with it.""" 
        start : float = min(abs(self.numerator), abs(self.denominator))
        gcf : float = 0
        
        
        while start > 2:
            if (self.numerator%start == 0) and (self.denominator%start == 0):
                gcf = start
                break
            start = start - 1
         
         
        if gcf > 0:   
          return Fraction(self.numerator / gcf , self.denominator / gcf)
        else:
          return Fraction(self.numerator , self.denominator )        
        

def main() -> None:
    flag: bool = True

    while flag:
        print("------------------------------------------------------")
        print("------------------------------------------------------")
        print('Welcome to the fraction calculator!')

        try:
            c1 = Parameter()
            # Initialize fraction 1 with numerator and denominator
            fraction1: FractionSimplify = c1.getFraction(1)
            # accept operator from user
            operator: str = c1.acceptOperator()
            # Initialize fraction 2 with numerator and denominator
            fraction2: FractionSimplify = c1.getFraction(2)

            # if operator is "==" ,then call function "equal" and display result.
            if operator in ['==', '!=', '<', '<=', '>', '>=']:
                print(
                    f"{fraction1} {operator} {fraction2} = {fraction1.checkEquality(fraction2, operator)}")
            else:
                # Perform operation on fraction1 and fraction2 and store result in fraction3
                fraction3Result: Fraction = fraction1.calculate(fraction2, operator)
                fraction3R : FractionSimplify = FractionSimplify(fraction3Result.numerator , fraction3Result.denominator)
                fraction3 = fraction3R.simplify()
                # prints result
                print(f"{fraction1} {operator} {fraction2} = {fraction3}")

            userInput = input(
                'If user want to quit press Q, else just enter : ')
            if userInput == "Q" or userInput == "q":
                flag = False

        except ValueError as e:
            print(f"Error : {e}")
            flag = False


if __name__ == '__main__':
    main()
