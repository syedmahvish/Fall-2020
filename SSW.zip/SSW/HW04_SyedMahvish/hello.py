def name_function() -> None :
    name : str = "Name": int = 26
    age : int = 26