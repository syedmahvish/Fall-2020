
from typing import Sequence, Any, Optional, Iterator

def count_vowels(s: str) -> int:
    """return the number of vowels in the string s."""
    
    if s == "" or s == None or not(isinstance(s, str)):
        raise ValueError(f"Given string : {s} is invalid String")
    
    inputStr : str = s.strip().lower()
    
    vowelCount : int = 0
    for character in inputStr:
        if character in ['a','e','i','o','u']:
           vowelCount = vowelCount + 1
    return vowelCount

def find_last(target: Any, seq: Sequence[Any]) -> Optional[int]:  
      """return the offset from 0 of the last occurrence of target in seq.""" 
      
      if target == None or target == "":
          raise ValueError(f"Given target : {target}  is invalid.")
      
      if seq == None or seq == "" or not seq:
          raise ValueError(f"Given sequence : {seq} is invalid.")
       
      lastOffset : Any = None
      for offset, item in enumerate(seq):
           if item == target :
               lastOffset = offset
      return lastOffset    
  

def my_enumerate(seq: Sequence[Any]) -> Iterator[Any]:   
     """emulate the behavior of Python's built in enumerate() function.

     For each call, return a tuple with the offset from 0 and the next
     item
     """  
     if seq == None or seq == "" or not seq:
        raise ValueError(f"Given sequence : {seq} is invalid.")
     
     i : int = 0
     myList : list = []
     for item in seq: 
       mytuple : tuple = (i, item)  
       i = i + 1
       myList.append(mytuple)
     return myList  
 
 
def main() -> None:
    print("--------------- Output --------------")
    
    

if __name__ == "__main__":    
    main()
 

 


      
      

   
