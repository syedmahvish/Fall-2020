from typing import IO, Iterator 

class StringDemo:
     
     
    def reverse(s: str) -> str:
        
        """This function checks if given string is empty , if so raise
        ValueError Else it will reverse given string using for loop."""
        
        if s == None or (s.isspace()) or (not s):
            raise ValueError(f"Given string is empty")
        
        reverse_string : str = ""
        
        for i in s:
            reverse_string = i + reverse_string
            
        return reverse_string
    
    def substring(target: str, s: str) -> int:
        
        """This function checks if given string or target is empty , if so
        raise ValueError Else it will check first occurence of target in given
        string and returns its index or position.

        If not found return -1
        """        
        if s == None or (s.isspace()) or (not s):
            raise ValueError(f"Given string is empty")
        
        if target == None or (target.isspace()) or (not target):
            raise ValueError(f"Given target is empty")
        
        length : int = len(target)
        i : int  = 0
        part_string : str = ""
        
        while i < len(s) :
            part_string = s[i:(i + length)]
            if part_string == target:
               return i
            i = i + 1
        
        return -1
        
    
    def find_second(target: str, s: str) -> int:
        
        """This function checks if given string or target is empty , if so
        raise ValueError Else it will check second occurence of target in given
        string and returns its index or position.

        If not found return -1
        """  
        if s == None or (s.isspace()) or (not s):
            raise ValueError(f"Given string is empty")
        
        if target == None or (target.isspace()) or (not target):
            raise ValueError(f"Given target is empty")
              
        found_first : bool = False
        length : int = len(target)
        i : int  = 0
        part_string : str = ""
        
        while i < len(s) :
            part_string = s[i:(i + length)]
            
            if found_first and part_string == target:
               return i 
            
            if part_string == target:
               found_first = True
            i = i + 1
        
        return -1
    
    def get_lines(path: str) -> Iterator[str] :
        
        """This function reads opens a given file and if path not found will
        raise error.

        It will return one line at a time until encounters with new line
        `\n` It will ignore comments
        """
        
        file_name : str = path
        try:
            fp : IO = open(file_name, "r", encoding="ISO-8859-1")                
        except FileNotFoundError:
            print(f"Can't open {file_name}")
        else:
            """Remove new line "\n" char from every line.

            Store single line or Combine all lines that continue and
            store in Iterator output.
            """
            output : Iterator[str] = []
            final_output : Iterator[str] = []
            temp_str : str = ""
            
            for line in fp:
                line = line.rstrip("\n")
                if line.endswith("\\") :
                    temp_str = temp_str + line[:-1]
                else :
                    temp_str = temp_str + line
                    output.append(temp_str)
                    temp_str = ""                                     
            fp.close() 
            
            """
              Exclude comments from Iterator output.
            """ 
            for idx, line in enumerate(output):
                if "#" in line:
                    location : int = line.find("#")
                    output[idx] = line[:location]
                if output[idx] :
                    final_output.append(output[idx])    
            
            return final_output                    
        
def main() -> None:
    
    try:
      s1 = StringDemo
    #   print(s1.reverse("Hello World"))
    #   print(s1.substring("He", "Hello World"))
    #   print(s1.substring("o", "Hello World"))
    #   print(s1.substring("xxx", "Hello World"))
    #   print(s1.find_second("l", "Hello World"))
    #   print(s1.find_second("e", "Hello World"))
          
    #   for line in s1.get_lines("/Users/mahvishsyed/Desktop/file.txt"):
    #       print(line)  
    except ValueError as e:
        print(e)
        
if __name__ == '__main__':
    main()