import unittest
from HW05_Mahvish_Syed import StringDemo

class StringDemoTest(unittest.TestCase): 
    
    
     def test_reverse(self) -> None:  
         
        self.assertRaises(ValueError,StringDemo.reverse,"")
        self.assertRaises(ValueError,StringDemo.reverse,None)
        self.assertRaises(ValueError,StringDemo.reverse,"       ")
        
        self.assertEqual(StringDemo.reverse("   a   "),"   a   ")
        self.assertEqual(StringDemo.reverse("Hello"),"olleH")
        self.assertEqual(StringDemo.reverse("Hello World"),"dlroW olleH")
        self.assertEqual(StringDemo.reverse("Hello World, Good Morning"),"gninroM dooG ,dlroW olleH")
        
        self.assertNotEqual(StringDemo.reverse("Hello World, Good Morning"),"gninroM dooG, dlroW olleH")
        self.assertNotEqual(StringDemo.reverse("Hello"),"leH")
        self.assertNotEqual(StringDemo.reverse("   a   "),"   a    ")
        
     def test_substring(self) -> None:
        
        self.assertRaises(ValueError,StringDemo.substring,"","")
        self.assertRaises(ValueError,StringDemo.substring,None," ")
        self.assertRaises(ValueError,StringDemo.substring,"       ","")
        self.assertRaises(ValueError,StringDemo.substring,"","Hello")
        self.assertRaises(ValueError,StringDemo.substring,None,"Hello")
        self.assertRaises(ValueError,StringDemo.substring,"       ","Hello") 
        self.assertRaises(ValueError,StringDemo.substring,"ello","")  
        
        self.assertEqual(StringDemo.substring("ell","Hello"),1)
        self.assertEqual(StringDemo.substring("He","Hello"),0)
        self.assertEqual(StringDemo.substring("xxx","Hello"),-1) 
        self.assertEqual(StringDemo.substring("o","Hello"),4) 
        
        self.assertNotEqual(StringDemo.substring("he","Hello"),0)
        
     def test_find_second(self) -> None:
        
        self.assertRaises(ValueError,StringDemo.find_second,"","")
        self.assertRaises(ValueError,StringDemo.find_second,None," ")
        self.assertRaises(ValueError,StringDemo.find_second,"       ","")
        self.assertRaises(ValueError,StringDemo.find_second,"","Hello")
        self.assertRaises(ValueError,StringDemo.find_second,None,"Hello")
        self.assertRaises(ValueError,StringDemo.find_second,"       ","Hello") 
        self.assertRaises(ValueError,StringDemo.find_second,"ello","")  
        
        self.assertEqual(StringDemo.find_second("ell","Hello"),-1)
        self.assertEqual(StringDemo.find_second("l","Hello"),3)
        self.assertEqual(StringDemo.find_second("xxx","Hello"),-1) 
        self.assertEqual(StringDemo.find_second("abba", "abbabba"),3)
        self.assertEqual(StringDemo.find_second("iss", "Mississippi"),4)
        self.assertEqual(StringDemo.find_second("a", "abaa"),2)  
         
        self.assertNotEqual(StringDemo.find_second("a","abaa"),3)  
        
      
     def test_get_lines(self) -> None:
        file_name = '/Users/mahvishsyed/Desktop/file.txt'
        expect: List[str] = ['<line0>', '<line1>', '<line2>', '<line3.1 line3.2 line3.3>','<line4.1 line4.2>', '<line5>', '<line6>']
        result: List[str] = list(StringDemo.get_lines(file_name))
         
        self.assertEqual(result, expect)
        
        expect = ['line0', '<line1>', '<line2>', '<line3.1 line3.2 line3.3>','<line4.1 line4.2>', '<line5>', '<line6']
        self.assertNotEqual(result, expect) 
         
if __name__ == '__main__':    
    unittest.main(exit=False, verbosity=2)