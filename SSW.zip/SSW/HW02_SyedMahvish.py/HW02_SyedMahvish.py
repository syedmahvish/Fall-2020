"""
  This program accepts two fractions from user in form of numerator and denominator.
  It performs calculation operation on given fractions like add, subtract, multiply and divides.
  It also checks if two fractions are equal or not.
"""

"""
  Class Fraction initialize fraction with numerator and denominator.
  It performs calculation operation on given fractions.
"""


class Fraction:

    """
      This function initialize fraction with given numerator and denominator.
      If denominator is zero , it raise exception ValueError.
      numerator : numerator of fraction.
      denominator : denominator of fraction.
      Returns none.
    """

    def __init__(self, numerator: float, denominator: float) -> None:
        self.numerator: float = numerator
        if(denominator == 0):
            raise ValueError("Denominator is zero")
        else:
            self.denominator: float = denominator

    """
      This function perform addition of two fraction
      self : current fraction
      other : another fraction
      Returns : result of two fraction addition in form of fraction
    """

    def plus(self, other: "Fraction") -> "Fraction":
        value1: float = self.numerator * other.denominator
        value2: float = other.numerator * self.denominator
        value3: float = self.denominator * other.denominator
        return Fraction(value1 + value2, value3)

    """
      This function perform subtraction of two fraction
      self : current fraction
      other : another fraction
      Returns : result of two fraction subtraction in form of fraction
    """

    def minus(self, other: "Fraction") -> "Fraction":
        value1: float = self.numerator * other.denominator
        value2: float = other.numerator * self.denominator
        value3: float = self.denominator * other.denominator
        return Fraction(value1 - value2, value3)

    """
      This function perform multiplication of two fraction
      self : current fraction
      other : another fraction
      Returns : result of two fraction multiplication in form of fraction
    """

    def times(self, other: "Fraction") -> "Fraction":
        value1: float = self.numerator * other.numerator
        value2: float = self.denominator * other.denominator
        return Fraction(value1, value2)

    """
      This function perform division of two fraction
      self : current fraction
      other : another fraction
      Returns : result of two fraction division in form of fraction
    """

    def divide(self, other: "Fraction") -> "Fraction":
        value1: float = self.numerator * other.denominator
        value2: float = self.denominator * other.numerator
        return Fraction(value1, value2)

    """
      This function checks if two fractions are equals or not.
      self : current fraction
      other : another fraction
      Returns : result as True if fractions are equals else False
    """

    def equal(self, other: "Fraction") -> bool:
        return (self.numerator * other.denominator) == (self.denominator * other.numerator)

    """
      This function perform calculation operation on two fraction based on given operator.
      self : current fraction
      other : another fraction
      operator : Specify which operation to be perform
      Returns : result of fractions operation in form of fraction
    """

    def calculate(self, other: "Fraction", operator: str) -> "Fraction":
        if(operator == "+"):
            return self.plus(other)
        elif(operator == "-"):
            return self.minus(other)
        elif(operator == "*"):
            return self.times(other)
        elif(operator == "/"):
            return self.divide(other)

    """
     This function display fraction in form of string
     Returns : string representation of fraction
    """

    def __str__(self) -> str:
        return f"{self.numerator}/{self.denominator}"


"""
  Class Parameter accepts numerator and denominator of fraction from user and initialize them.
  It also accepts operator (+ , - , *, / , == ) from user which specify what operation to be performed on fractions.
"""


class Parameter:

    """
      This function accepts input (numerator and denominator) from user
      if input is invalid it handles Exception ValueError.
      fracNum : specify number of fraction i.e fraction 1 or 2 and so on.
      fracPart : specify numerator or denominator of fraction.
      Returns input converting it into float number.
    """

    def accept_input(self, fracNum: int, fracPart: str) -> float:
        while True:
            value: str = input(f"Fraction {fracNum} {fracPart}: ")
            try:
                return float(value)
            except ValueError:
                print(f"given value {value} is not a number")

    """
      This function calls acceptInput() function to accept input from user.
      Once it accepts numerator and denominator it initialize fraction.
      fracNum : specify number of fraction i.e fraction 1 or 2 and so on.
      Returns fraction object.
    """

    def get_fraction(self, fracNum: int) -> "Fraction":
        numerator: float = self.acceptInput(fracNum, "numerator")
        denominator: float = self.acceptInput(fracNum, "denominator")
        return Fraction(numerator, denominator)

    """
      This function accepts operator from user from given choice.
      Returns operator in form of string.
    """

    def accept_operator(self) -> str:
        operator: str = input(f"Operation (+, -, *, /, == ): ")
        while True:
            if operator == "+" or operator == "-" or operator == "*" or operator == "/" or operator == " == ":
                return operator
            else:
                print(f"given value {operator} is not a valid operator")
                operator = input(f"Operation (+, -, *, /, == ): ")


"""
  This function test whether all operation(plus, minus, times, divide) generates desired result or not.
  It display result with expected output.
"""


def test_suite():
    f12 = Fraction(1, 2)
    f44 = Fraction(4, 4)
    f128 = Fraction(12, 8)
    f32 = Fraction(3, 2)

    print(" --  --  --  --  --  --  -- Test case for two fraction addition --  --  --  --  --  --  --  -- -")
    result = f12.calculate(f12, "+")
    print(f"{f12} + {f12} = {result} [4/4]")

    result = f12.calculate(f44, "+")
    print(f"{f12} + {f44} = {result} [12/8]")

    result = f12.calculate(f128, "+")
    print(f"{f12} + {f128} = {result} [32/16]")

    result = f12.calculate(f32, "+")
    print(f"{f12} + {f32} = {result} [8/4]")

    print(" --  --  --  --  --  --  -- Test case for two fraction subtraction --  --  --  --  --  --  --  -- -")
    result = f12.calculate(f12, "-")
    print(f"{f12} - {f12} = {result} [0/4]")

    result = f44.calculate(f12, "-")
    print(f"{f44} - {f12} = {result} [4/8]")

    result = f12.calculate(f128, "-")
    print(f"{f12} - {f128} = {result} [-16/16]")

    result = f12.calculate(f32, "-")
    print(f"{f12} - {f32} = {result} [-4/4]")

    print(" --  --  --  --  --  --  -- Test case for two fraction multiplication --  --  --  --  --  --  --  -- -")
    result = f12.calculate(f12, "*")
    print(f"{f12} * {f12} = {result} [1/4]")

    result = f44.calculate(f12, "*")
    print(f"{f44} * {f12} = {result} [4/8]")

    result = f12.calculate(f128, "*")
    print(f"{f12} * {f128} = {result} [12/16]")

    result = f12.calculate(f32, "*")
    print(f"{f12} * {f32} = {result} [3/4]")

    print(" --  --  --  --  --  --  -- Test case for two fraction division --  --  --  --  --  --  --  -- -")
    result = f12.calculate(f12, "/")
    print(f"{f12} / {f12} = {result} [2/2]")

    result = f44.calculate(f12, "/")
    print(f"{f44} / {f12} = {result} [8/4]")

    result = f12.calculate(f128, "/")
    print(f"{f12} / {f128} = {result} [8/24]")

    result = f12.calculate(f32, "/")
    print(f"{f12} / {f32} = {result} [2/6]")

    print(" --  --  --  --  --  --  -- Test case for two fraction equality --  --  --  --  --  --  --  -- -")
    result = f128.equal(f32)
    print(f"{f128} == {f32} = {result} [true]")

    result = f44.equal(f12)
    print(f"{f44} == {f12} = {result} [false]")

    print(" --  --  --  --  --  --  -- Test case for three fraction addition --  --  --  --  --  --  --  -- -")
    result = (f12.calculate(f32, "+")).calculate(f44, "+")
    print(f"{f12} + {f32}  + {f44} = {result} [48/16]")


"""
   It accepts two fraction from user and operator
   Continue to run application until user enters Quit.
"""


def main() -> None:
    flag: bool = True

    while flag:
        print(" --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  -- ")
        print(" --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  --  -- ")
        print('Welcome to the fraction calculator!')

        try:
            c1 = Parameter()
            # Initialize fraction 1 with numerator and denominator
            fraction1: Fraction = c1.getFraction(1)
            # accept operator from user
            operator: str = c1.acceptOperator()
            # Initialize fraction 2 with numerator and denominator
            fraction2: Fraction = c1.getFraction(2)

            # if operator is " == " , then call function "equal" and display result.
            if operator == " == ":
                print(
                    f"{fraction1} {operator} {fraction2} = {fraction1.equal(fraction2)}")
            else:
                # Perform operation on fraction1 and fraction2 and store result in fraction3
                fraction3: Fraction = fraction1.calculate(fraction2, operator)
                # prints result
                print(f"{fraction1} {operator} {fraction2} = {fraction3}")

            userInput = input(
                'If user want to quit press Q, else just enter : ')
            if userInput == "Q" or userInput == "q":
                flag = False

        except ValueError as e:
            print(f"Error : {e}")


if __name__ == '__main__':
    test_suite()
    main()
