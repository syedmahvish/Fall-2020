import unittest
from HW07_Mahvish_Syed import Anagram, Alphabet, WebAnalyzer

class AnagramTest(unittest.TestCase): 
    
    
    def test_anagrams_lst(self) -> None:         
        """This fuction test anagrams_lst() method."""
        
        self.assertRaises(ValueError,Anagram.anagrams_lst,"", "")
        self.assertRaises(ValueError,Anagram.anagrams_lst,None,"")
        self.assertRaises(ValueError,Anagram.anagrams_lst,"   ",123)
        self.assertRaises(ValueError,Anagram.anagrams_lst,[23,True],"cinema")
        
        self.assertEqual(Anagram.anagrams_lst("cinema", "iceman"), True)
        self.assertEqual(Anagram.anagrams_lst("dirtyroom", "dormitory"), True)
        self.assertEqual(Anagram.anagrams_lst("Moon", "Noon"), False)
        
        self.assertNotEqual(Anagram.anagrams_lst("cinema", "ice"), True)
        
    def test_anagrams_dd(self) -> None:         
        """This fuction test anagrams_dd() method."""
        
        self.assertRaises(ValueError,Anagram.anagrams_dd,"", "")
        self.assertRaises(ValueError,Anagram.anagrams_dd,None,"")
        self.assertRaises(ValueError,Anagram.anagrams_dd,"   ",123)
        self.assertRaises(ValueError,Anagram.anagrams_dd,[23,True],"cinema")
        
        self.assertEqual(Anagram.anagrams_dd("cinema", "iceman"), True)
        self.assertEqual(Anagram.anagrams_dd("dirtyroom", "dormitory"), True)
        self.assertEqual(Anagram.anagrams_dd("Moon", "Noon"), False)
        
        self.assertNotEqual(Anagram.anagrams_lst("cinema", "ice"), True) 
        
    def test_anagrams_cntr(self) -> None:         
        """This fuction test anagrams_cntr() method."""
        
        self.assertRaises(ValueError,Anagram.anagrams_cntr,"", "")
        self.assertRaises(ValueError,Anagram.anagrams_cntr,None,"")
        self.assertRaises(ValueError,Anagram.anagrams_cntr,"   ",123)
        self.assertRaises(ValueError,Anagram.anagrams_cntr,[23,True],"cinema")
        
        self.assertEqual(Anagram.anagrams_cntr("cinema", "iceman"), True)
        self.assertEqual(Anagram.anagrams_cntr("dirtyroom", "dormitory"), True)
        self.assertEqual(Anagram.anagrams_cntr("Moon", "Noon"), False)
        
        self.assertNotEqual(Anagram.anagrams_cntr("cinema", "ice"), True) 

        
class AlphabetTest(unittest.TestCase): 
    
    
    def test_covers_alphabet(self) -> None:         
        """This fuction test covers_alphabet() method."""
        
        self.assertRaises(ValueError,Alphabet.covers_alphabet,"")
        self.assertRaises(ValueError,Alphabet.covers_alphabet,None)
        self.assertRaises(ValueError,Alphabet.covers_alphabet,"   ")
        self.assertRaises(ValueError,Alphabet.covers_alphabet,[23,True])
        self.assertRaises(ValueError,Alphabet.covers_alphabet,780)
        
        self.assertEqual(Alphabet.covers_alphabet("abcdefghijklmnopqrstuvwxyz"), True)
        self.assertEqual(Alphabet.covers_alphabet("aabbcdefghijklmnopqrstuvwxyzzabc"), True)
        self.assertEqual(Alphabet.covers_alphabet("The quick brown fox jumps over the lazy dog"), True)
        self.assertEqual(Alphabet.covers_alphabet("We promptly judged antique ivory buckles for the next prize"), True)
        self.assertEqual(Alphabet.covers_alphabet("The,,,  \n 1234$%%, quick, brown 567 \n, fox; jumps over the lazy dog!%^&&"), True)
        self.assertEqual(Alphabet.covers_alphabet("xyz"), False)
        self.assertEqual(Alphabet.covers_alphabet("123456789#@#%%@#% SDASASFASFASASD"), False)
        self.assertEqual(Alphabet.covers_alphabet("1234567890asdfghjkLQwertyuiopzxcvbnm"), True)
        
        self.assertNotEqual(Alphabet.covers_alphabet("xyz"), True) 
        
class WebAnalyzerTest(unittest.TestCase): 
    
    
    def test_web_analyzer(self) -> None:  
        """This fuction test web_analyzer() method.""" 
        weblogs_error: List[Tuple[str, str]] = [
            ('Nanda', None), ('Maha', 123), 
            ('Fei', 'python.org'), ('Maha', 'google.com'), 
            ('Fei', 'python.org'), ('Nanda', 'python.org'), 
            ('Fei', 'dzone.com'), ('Nanda', 'google.com'), 
            ('Maha', 'google.com'), ] 
        self.assertRaises(ValueError,WebAnalyzer.web_analyzer,weblogs_error)  
        self.assertRaises(ValueError,WebAnalyzer.web_analyzer,[])
        self.assertRaises(ValueError,WebAnalyzer.web_analyzer,None)
        self.assertRaises(ValueError,WebAnalyzer.web_analyzer,"abc") 
        
        weblogs: List[Tuple[str, str]] = [
            ('Nanda', 'google.com'), ('Maha', 'google.com'), 
            ('Fei', 'python.org'), ('Maha', 'google.com'), 
            ('Fei', 'python.org'), ('Nanda', 'python.org'), 
            ('Fei', 'dzone.com'), ('Nanda', 'google.com'), 
            ('Maha', 'google.com'), ]
        summary: List[Tuple[str, List[str]]] = [
            ('dzone.com', ['Fei']), 
            ('google.com', ['Maha', 'Nanda']), 
            ('python.org', ['Fei', 'Nanda']), ]

        self.assertEqual(WebAnalyzer.web_analyzer(weblogs), summary) 
        
                      
        
if __name__ == '__main__':    
    unittest.main(exit=False, verbosity=2)