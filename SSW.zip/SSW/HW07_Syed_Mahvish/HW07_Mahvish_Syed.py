from collections import defaultdict, Counter
from typing import Set, List, Tuple
import collections

class Anagram:
    
    def anagrams_lst(str1: str, str2: str) -> bool :
        """This function returns True if str1 and str2 are anagrams, False if
        not.

        It uses only list
        """
        
        if not isinstance(str1, str) or not str1 or len(str1.strip()) == 0:
                raise ValueError(f"Given {str1} is not a valid String")
        if not isinstance(str2, str) or not str2 or len(str2.strip()) == 0:
                raise ValueError(f"Given {str2} is not a valid String")
             
        return sorted(str1) == sorted(str2)
    
    def anagrams_dd(str1: str, str2: str) -> bool:
        """This function returns True if str1 and str2 are anagrams, False if
        not.

        It uses defaultdict
        """
        
        if not isinstance(str1, str) or not str1 or len(str1.strip()) == 0:
                raise ValueError(f"Given {str1} is not a valid String")
        if not isinstance(str2, str) or not str2 or len(str2.strip()) == 0:
                raise ValueError(f"Given {str2} is not a valid String")
            
        dd : defaultdict[str , int] =  defaultdict(int)
        
        for item in str1:
            dd[item] += 1 
        
        for item in str2:
            dd[item] -= 1        
         
        for value in dd.values():
            if value != 0:
                return False
        
        return True 
    
    def anagrams_cntr(str1: str, str2: str) -> bool:
        """This function returns True if str1 and str2 are anagrams, False if
        not.

        It uses Counter
        """
        
        if not isinstance(str1, str) or not str1 or len(str1.strip()) == 0:
                raise ValueError(f"Given {str1} is not a valid String")
        if not isinstance(str2, str) or not str2 or len(str2.strip()) == 0:
                raise ValueError(f"Given {str2} is not a valid String")  
            
        return collections.Counter(str1) == collections.Counter(str2)  
    
class Alphabet:
    
    def covers_alphabet(sentence: str) -> bool:
        """This function returns True if sentence includes at least one
        instance of every character in the alphabet or False using only Python
        sets."""
       
        if not isinstance(sentence, str) or not sentence or len(sentence.strip()) == 0:
                raise ValueError(f"Given {sentence} is not a valid String")
       
        sentence = "".join(item for item in sentence if item.isalpha())
        alphabet_set : Set[str] = set("abcdefghijklmnopqrstuvwxyz")
        sentence_set : Set[str] = set(sentence.lower()) 
        
        return len(sentence_set) == len(alphabet_set)
    
class WebAnalyzer:
    
    
    def web_analyzer(weblogs: List[Tuple[str, str]]) -> List[Tuple[str, List[str]]]:
        """This function creates a summary of the weblogs with each distinct
        site and a sorted list of names of distinct people who visited that
        site.""" 
        
        if not isinstance(weblogs, list) or not weblogs:
            raise ValueError(f"Given {weblogs} is not a list") 
        
        for item in weblogs:
            if not isinstance(item, tuple) or len(item) != 2 or not isinstance(item[0], str) or not item[0] or len(item[0].strip()) == 0 or not isinstance(item[1], str) or not item[1] or len(item[1].strip()) == 0:
                raise ValueError(f"Given {item} is not a Tuple or insufficient value is passed")
            
        summary : list[Tuple[str, list[str]]] = list()
        
        employee_info : defaultdict[str, list[str]] = defaultdict()
        
        for item in weblogs:
            list_employee : list[str] = list()
            if item[1] in employee_info:
               list_employee = employee_info.get(item[1])
               
            if item[0] not in list_employee: 
               list_employee.append(item[0])
               
            list_employee.sort()
            employee_info[item[1]] = list_employee
        
        summary = [(website, employee_name) for website, employee_name in sorted(employee_info.items())]  
        return summary         
                          
def main():
    try:
     weblogs: List[Tuple[str, str]] = [
     ('Nanda', 'google.com'), ('Maha', 'google.com'), 
     ('Fei', 'python.org'), ('Maha', 'google.com'), 
     ('Fei', 'python.org'), ('Nanda', 'python.org'), 
     ('Fei', 'dzone.com'), ('Nanda', 'google.com'), 
     ('Maha', 'google.com'), ]
    #  print(WebAnalyzer.web_analyzer(weblogs))
    #   print(ana.anagrams_lst("cinema", "icema")) 
      
    except ValueError as e:  
       print(e)    
    
if __name__ == '__main__':
    main()          
    
