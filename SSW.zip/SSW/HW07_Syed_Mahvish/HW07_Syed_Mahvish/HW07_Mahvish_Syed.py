"""
@author : Syed Mahvish
CWID : 10456845
"""

from collections import defaultdict
from typing import Set, List, Tuple, DefaultDict
import collections

class Anagram:
    """This class demostrate use of list, tuple, dict, defaultdict, and set"""


    def anagrams_lst(self, str1: str, str2: str) -> bool :
        """This function returns True if str1 and str2 are anagrams, False if
        not.

        It uses only list
        """

        if not isinstance(str1, str) or not str1 or len(str1.strip()) == 0:
            raise ValueError(f"Given {str1} is not a valid String")
        if not isinstance(str2, str) or not str2 or len(str2.strip()) == 0:
            raise ValueError(f"Given {str2} is not a valid String")
        return sorted(str1) == sorted(str2)

    def anagrams_dd(self, str1: str, str2: str) -> bool:
        """This function returns True if str1 and str2 are anagrams, False if
        not.

        It uses defaultdict
        """

        if not isinstance(str1, str) or not str1 or len(str1.strip()) == 0:
            raise ValueError(f"Given {str1} is not a valid String")
        if not isinstance(str2, str) or not str2 or len(str2.strip()) == 0:
            raise ValueError(f"Given {str2} is not a valid String")

        dict_string : DefaultDict[str , int] =  defaultdict(int)

        for item in str1:
            dict_string[item] += 1
        for item in str2:
            dict_string[item] -= 1

        for value in dict_string.values():
            if value != 0:
                return False
        return True

    def anagrams_cntr(self, str1: str, str2: str) -> bool:
        """This function returns True if str1 and str2 are anagrams, False if
        not.

        It uses Counter
        """
        if not isinstance(str1, str) or not str1 or len(str1.strip()) == 0:
            raise ValueError(f"Given {str1} is not a valid String")
        if not isinstance(str2, str) or not str2 or len(str2.strip()) == 0:
            raise ValueError(f"Given {str2} is not a valid String")

        return collections.Counter(str1) == collections.Counter(str2)

class Alphabet:
    """This class demonstrate use of string and set"""


    def covers_alphabet(self, sentence: str) -> bool:
        """This function returns True if sentence includes at least one
        instance of every character in the alphabet or False using only Python
        sets."""

        if not isinstance(sentence, str) or not sentence or len(sentence.strip()) == 0:
            raise ValueError(f"Given {sentence} is not a valid String")

        sentence = "".join(item for item in sentence if item.isalpha())
        alphabet_set : Set[str] = set("abcdefghijklmnopqrstuvwxyz")
        sentence_set : Set[str] = set(sentence.lower())

        return len(sentence_set) == len(alphabet_set)

class WebAnalyzer:
    """This class demonstrate use of tuples, list,string and set"""


    def web_analyzer(self, weblogs: List[Tuple[str, str]]) -> List[Tuple[str, List[str]]]:
        """This function creates a summary of the weblogs with each distinct
        site and a sorted list of names of distinct people who visited that
        site."""

        if not isinstance(weblogs, list) or not weblogs:
            raise ValueError(f"Given {weblogs} is not a list")

        for item in weblogs:
            if not isinstance(item, tuple) or len(item) != 2:
                if not isinstance(item[0], str) or not item[0] or len(item[0].strip()) == 0:
                    if not isinstance(item[1], str) or not item[1] or len(item[1].strip()) == 0:
                        raise ValueError(f"Given {item} is not a Tuple or invalid value is passed")

        summary : List[Tuple[str, List[str]]] = list()
        employee_info : DefaultDict[str, List[str]] = defaultdict()

        for item in weblogs:
            list_employee : List[str] = list()

            if item[1] in employee_info:
                list_employee = employee_info.get(item[1])
            if item[0] not in list_employee:
                list_employee.append(item[0])

            list_employee.sort()
            employee_info[item[1]] = list_employee

        summary = [(website, employee_name) for website, employee_name in sorted(employee_info.items())]
        return summary

def main():
    """
    This functions create object of above defined classes
    Calls method.
    """

    try:
        weblogs: List[Tuple[str, str]] = [('Nanda', 'google.com'), ('Maha', 'google.com'),
                                            ('Fei', 'python.org'), ('Maha', 'google.com'),
                                            ('Fei', 'python.org'), ('Nanda', 'python.org'),
                                            ('Fei', 'dzone.com'), ('Nanda', 'google.com'),
                                            ('Maha', 'google.com'), ]
    #  print(WebAnalyzer.web_analyzer(weblogs))
    #   print(ana.anagrams_lst("cinema", "icema"))
    except ValueError as value_error:
        print(value_error)

if __name__ == '__main__':
    main()
    