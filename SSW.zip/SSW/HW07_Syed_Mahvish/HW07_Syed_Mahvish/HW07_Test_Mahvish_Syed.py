"""
@author : Syed Mahvish
CWID : 10456845
"""

import unittest
from HW07_Mahvish_Syed import Anagram, Alphabet, WebAnalyzer
from typing import List, Tuple

class AnagramTest(unittest.TestCase):
    """This class test Anagram class and its method"""


    def test_anagrams_lst(self) -> None:
        """This fuction test anagrams_lst() method."""
        anagram = Anagram()

        self.assertRaises(ValueError,anagram.anagrams_lst,"", "")
        self.assertRaises(ValueError,anagram.anagrams_lst,None,"")
        self.assertRaises(ValueError,anagram.anagrams_lst,"   ",123)
        self.assertRaises(ValueError,anagram.anagrams_lst,[23,True],"cinema")

        self.assertEqual(anagram.anagrams_lst("cinema", "iceman"), True)
        self.assertEqual(anagram.anagrams_lst("dirtyroom", "dormitory"), True)
        self.assertEqual(anagram.anagrams_lst("Moon", "Noon"), False)

        self.assertNotEqual(anagram.anagrams_lst("cinema", "ice"), True)

    def test_anagrams_dd(self) -> None:
        """This fuction test anagrams_dd() method."""
        anagram = Anagram()

        self.assertRaises(ValueError,anagram.anagrams_dd,"", "")
        self.assertRaises(ValueError,anagram.anagrams_dd,None,"")
        self.assertRaises(ValueError,anagram.anagrams_dd,"   ",123)
        self.assertRaises(ValueError,anagram.anagrams_dd,[23,True],"cinema")

        self.assertEqual(anagram.anagrams_dd("cinema", "iceman"), True)
        self.assertEqual(anagram.anagrams_dd("dirtyroom", "dormitory"), True)
        self.assertEqual(anagram.anagrams_dd("Moon", "Noon"), False)

        self.assertNotEqual(anagram.anagrams_lst("cinema", "ice"), True)

    def test_anagrams_cntr(self) -> None:
        """This fuction test anagrams_cntr() method."""
        anagram = Anagram()

        self.assertRaises(ValueError,anagram.anagrams_cntr,"", "")
        self.assertRaises(ValueError,anagram.anagrams_cntr,None,"")
        self.assertRaises(ValueError,anagram.anagrams_cntr,"   ",123)
        self.assertRaises(ValueError,anagram.anagrams_cntr,[23,True],"cinema")

        self.assertEqual(anagram.anagrams_cntr("cinema", "iceman"), True)
        self.assertEqual(anagram.anagrams_cntr("dirtyroom", "dormitory"), True)
        self.assertEqual(anagram.anagrams_cntr("Moon", "Noon"), False)

        self.assertNotEqual(anagram.anagrams_cntr("cinema", "ice"), True)

class AlphabetTest(unittest.TestCase):
    """This class test Alphabet class and its method"""


    def test_covers_alphabet(self) -> None:
        """This fuction test covers_alphabet() method."""
        alphabet = Alphabet()

        self.assertRaises(ValueError,alphabet.covers_alphabet,"")
        self.assertRaises(ValueError,alphabet.covers_alphabet,None)
        self.assertRaises(ValueError,alphabet.covers_alphabet,"   ")
        self.assertRaises(ValueError,alphabet.covers_alphabet,[23,True])
        self.assertRaises(ValueError,alphabet.covers_alphabet,780)

        self.assertEqual(alphabet.covers_alphabet("abcdefghijklmnopqrstuvwxyz"), True)
        self.assertEqual(alphabet.covers_alphabet("aabbcdefghijklmnopqrstuvwxyzzabc"), True)
        self.assertEqual(alphabet.covers_alphabet("The quick brown fox jumps over the lazy dog"),
                                                    True)
        self.assertEqual(alphabet.covers_alphabet(
            "We promptly judged antique ivory buckles for the next prize"),True)
        self.assertEqual(alphabet.covers_alphabet(
            "The,,,  \n 1234$%%, quick, brown 567 \n, fox; jumps over the lazy dog!%^&&"),
            True)
        self.assertEqual(alphabet.covers_alphabet("xyz"), False)
        self.assertEqual(alphabet.covers_alphabet("123456789#@#%%@#% SDASASFASFASASD"), False)
        self.assertEqual(alphabet.covers_alphabet("1234567890asdfghjkLQwertyuiopzxcvbnm"), True)

        self.assertNotEqual(alphabet.covers_alphabet("xyz"), True)

class WebAnalyzerTest(unittest.TestCase):
    """This class test web analyser"""

    def test_web_analyzer(self) -> None:
        """This fuction test web_analyzer() method."""
        webanalyser = WebAnalyzer()

        self.assertRaises(ValueError,webanalyser.web_analyzer,[])
        self.assertRaises(ValueError,webanalyser.web_analyzer,None)
        self.assertRaises(ValueError,webanalyser.web_analyzer,"abc")

        weblogs: List[Tuple[str, str]] = [('Nanda', 'google.com'), ('Maha', 'google.com'),
                                        ('Fei', 'python.org'), ('Maha', 'google.com'),
                                        ('Fei', 'python.org'), ('Nanda', 'python.org'),
                                        ('Fei', 'dzone.com'), ('Nanda', 'google.com'),
                                        ('Maha', 'google.com'), ]
        summary: List[Tuple[str, List[str]]] = [('dzone.com', ['Fei']),
                                                ('google.com', ['Maha', 'Nanda']),
                                                ('python.org', ['Fei', 'Nanda']), ]
        self.assertEqual(webanalyser.web_analyzer(weblogs), summary)

if __name__ == '__main__':
    unittest.main(exit=False, verbosity=2)
