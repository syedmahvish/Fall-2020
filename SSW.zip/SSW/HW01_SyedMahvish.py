""" This program illustrate Rock , Scissors and Paper game between human and computer.
It allows user to enter Rock , Scissors or Paper and randomly chose computer input. 
Display who wins the game."""


import random

""" dictionary for computer to randomly select Rock, Paper or  Scissors"""
computerChoiceList = ["R", "P", "S"]

""" dictionary to display result based on human and computer input """
playDict =	{
    ("R", "R") : "tie",
    ("R", "S") : "win",
    ("R", "P") : "lose",
    ("P", "R") : "win" ,
    ("P", "S") : "lose",
    ("P", "P") : "tie",
    ("S", "R") : "lose" ,
    ("S", "S") : "tie",
    ("S", "P") : "win"
}


""" dict to get name based on abbreviation """
acronymDict = { "R" : "Rock",
               "S" : "Scissors",
               "P" : "Paper"
    
}

""" Read input from user.
    Validate if user enters valid input from given choice. If so it returns userinput.
    Else set flag to true and allow user to re-enter valid input.
    Once user enters valid choice, set flag to flase and returns userinput """
def readUserInput() -> str:
    userInput = input("Please choose 'R', 'P', 'S' or 'Q' to quit:")
    userInput = userInput.upper()
    
    flag : bool = False
    
    if userInput != 'R' and userInput != 'P' and userInput != 'S' and userInput != 'Q' :
         print("Please enter valid input from given options.")
         flag = True
         
    while flag:
         userInput = input("Please choose 'R', 'P', 'S' or 'Q' to quit:")
         userInput = userInput.upper() 
         if userInput != 'R' and userInput != 'P' and userInput != 'S' and userInput != 'Q' :
             print("Please enter valid input from given options.")
             flag = True 
         else:
             flag = False       
         
    return userInput
    

""" Use random to choice randomly input from Rock,Paper or Scissor. 
    Returns computer choice.  """
def readComputerInput() -> str:
    computerInput = random.choice(computerChoiceList)
    return computerInput

""" Reads user and computer input.
    If user chose to quit, it abort game.
    Else check user and computer input and display result.
    Continues to play until user chose to Quit. """
def playGame()  :
    computerInput: str = readComputerInput()
    userInput: str = readUserInput()
    
    if userInput == 'Q':
        print("Thanks for playing!")
        return
    else:
       result: str =  playDict[userInput, computerInput]
       message : str = ""
       if(result == "win") :
         message = acronymDict.get(userInput) + " beats " + acronymDict.get(computerInput) + " - You win!"
       elif (result == "lose"):   
         message = acronymDict.get(computerInput) + " beats " + acronymDict.get(userInput) + " - I win!"
       else :
          message = "Tie: we both chose" +  acronymDict.get(computerInput)  
       print(message) 
       playGame()     
       
    
def main() :
    playGame()

if __name__ == "__main__":
    main()    
