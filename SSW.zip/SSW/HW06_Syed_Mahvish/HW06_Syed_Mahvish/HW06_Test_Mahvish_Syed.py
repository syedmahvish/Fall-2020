"""@author : Syed Mahvish
CWID : 10456845"""

import unittest
from HW06_Mahvish_Syed import ListDemo, DonutQueue

class ListDemoTest(unittest.TestCase):
    """ This class test functions of class ListDemo.
    It test functionality with combination of input
    It test exception handling too."""

    def test_list_copy(self) -> None:
        """This fuction test list_copy() method."""

        list_demo = ListDemo()
        self.assertRaises(ValueError,list_demo.list_copy,"")
        self.assertRaises(ValueError,list_demo.list_copy,None)
        self.assertRaises(ValueError,list_demo.list_copy,"ABchkl")
        self.assertRaises(ValueError,list_demo.list_copy,"    ")
        self.assertRaises(ValueError,list_demo.list_copy,"12378")

        self.assertEqual(list_demo.list_copy([1,2,3,4]),[1,2,3,4])
        self.assertEqual(list_demo.list_copy(["one","two","three","four","five"]),
                                                ["one","two","three","four","five"])
        self.assertEqual(list_demo.list_copy(["one",2,True,[1,2],"five"]),
                                                ["one",2,True,[1,2],"five"])

        self.assertNotEqual(list_demo.list_copy(["one",2,True,[1,2],"five"]),
                                                ["one",2,True,[1,2]])

    def test_list_intersect(self) -> None:
        """This fuction test list_intersect() method."""

        list_demo = ListDemo()

        self.assertRaises(ValueError,list_demo.list_intersect,"",None)
        self.assertRaises(ValueError,list_demo.list_intersect,"ABC","ABCD")
        self.assertRaises(ValueError,list_demo.list_intersect,"12378","    ")
        self.assertRaises(ValueError,list_demo.list_intersect,"12378",[1,2,3,4])

        self.assertEqual(list_demo.list_intersect([1,2,3,4],[1,2,3]),[1,2,3])
        self.assertEqual(list_demo.list_intersect([1,2,3,4],[6,7,8,9,10]),[])
        self.assertEqual(list_demo.list_intersect(["one","two"],
                        ["one","two","three","four","five"]),["one","two"])
        self.assertEqual(list_demo.list_intersect(["one",True,[1,2]],
                        ["one",2,True,[1,2],"five"]),["one",True,[1,2]])

    def test_list_difference(self) -> None:
        """This fuction test list_difference() method."""

        list_demo = ListDemo()

        self.assertRaises(ValueError,list_demo.list_difference,"",None)
        self.assertRaises(ValueError,list_demo.list_difference,"ABC","ABCD")
        self.assertRaises(ValueError,list_demo.list_difference,"12378","    ")
        self.assertRaises(ValueError,list_demo.list_difference,"12378",[1,2,3,4])

        self.assertEqual(list_demo.list_difference([1,2,3,4],[1,2,3]),[4])
        self.assertEqual(list_demo.list_difference([1,2,3,4],[6,7,8,9,10]),[1,2,3,4])
        self.assertEqual(list_demo.list_difference(["one","two"],
                                                ["one","two","three","four","five"]),[])
        self.assertEqual(list_demo.list_difference(["one",True,[1,2]],
                                                ["one",2,True,[1,2],"five"]),[])

    def test_remove_vowels(self) -> None:
        """This fuction test remove_vowels() method."""

        list_demo = ListDemo()

        self.assertRaises(ValueError,list_demo.remove_vowels,"     ")
        self.assertRaises(ValueError,list_demo.remove_vowels,"")
        self.assertRaises(ValueError,list_demo.remove_vowels,None)
        self.assertRaises(ValueError,list_demo.remove_vowels,  12378   )
        self.assertRaises(ValueError,list_demo.remove_vowels,[1,2,3,4])

        self.assertEqual(list_demo.remove_vowels("Amy is my favorite daughter"),
                                                    "my favorite daughter")
        self.assertEqual(list_demo.remove_vowels("Jan is my best friend"),
                                                    "Jan my best friend")
        self.assertEqual(list_demo.remove_vowels("Amy ate a apple"),"")
        self.assertEqual(list_demo.remove_vowels("Does not conatin vowels"),
                                                    "Does not conatin vowels")

        self.assertNotEqual(list_demo.remove_vowels("Jan is my best friend"),
                                                    "Jan is my best friend")

    def test_check_pwd(self) -> None:
        """This fuction test check_pwd() method."""

        list_demo = ListDemo()

        self.assertRaises(ValueError,list_demo.check_pwd,"     ")
        self.assertRaises(ValueError,list_demo.check_pwd,"")
        self.assertRaises(ValueError,list_demo.check_pwd,None)
        self.assertRaises(ValueError,list_demo.check_pwd,  12378   )
        self.assertRaises(ValueError,list_demo.check_pwd,[1,2,3,4])

        self.assertEqual(list_demo.check_pwd("Amy is my favorite daughter"),False)
        self.assertEqual(list_demo.check_pwd("12AMYpappert"),True)
        self.assertEqual(list_demo.check_pwd("Hello34"),False)
        self.assertEqual(list_demo.check_pwd("12Pas$%#swORD"),True)
        self.assertEqual(list_demo.check_pwd("Pas$%#s4567wORD"),False)

class DonutQueueTest(unittest.TestCase):
    """ This class test functions of class DonutQueue.
    It test functionality with combination of input
    It test exception handling too."""

    def test_queue(self):
        """This fuction test all Donutqueue methods arrive(), waiting() and
        next_customer()."""

        donut_queue = DonutQueue()
        self.assertIsNone(donut_queue.next_customer())
        donut_queue.arrive("Sujit", False)
        donut_queue.arrive("Fei", False)
        donut_queue.arrive("Prof JR", True)
        self.assertEqual(donut_queue.waiting(), "Prof JR, Sujit, Fei")
        donut_queue.arrive("Nanda", True)
        self.assertEqual(donut_queue.waiting(), "Prof JR, Nanda, Sujit, Fei")
        self.assertEqual(donut_queue.next_customer(), "Prof JR")
        self.assertEqual(donut_queue.next_customer(), "Nanda")
        self.assertEqual(donut_queue.next_customer(), "Sujit")
        self.assertEqual(donut_queue.waiting(), "Fei")
        self.assertEqual(donut_queue.next_customer(), "Fei")
        self.assertIsNone(donut_queue.next_customer())

if __name__ == '__main__':
    unittest.main(exit=False, verbosity=2)
