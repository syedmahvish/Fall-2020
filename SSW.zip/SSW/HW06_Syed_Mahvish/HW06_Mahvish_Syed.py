from typing import  List, Any, Optional

class ListDemo:
    
    
    def list_copy(l: List[Any]) -> List[Any]:
        
        """This function takes a list as a parameter and returns a copy of the
        list using a list comprehension."""
        
        if not isinstance(l, list):
            raise ValueError(f"Given {l} is not a list")
        
        result : List[Any] = list()
        
        result= [item for item in l]
        
        return result
    
    def list_intersect(l1: List[Any], l2: List[Any]) -> List[Any]:
        
        """This function takes two lists as  parameters and returns a new list
        with the values that are included in both lists using a list
        comprehension."""
        
        if not isinstance(l1, list):
            raise ValueError(f"Given {l1} is not a list")
        if not isinstance(l2, list):
            raise ValueError(f"Given {l2} is not a list")
        
        result : List[Any] = list()
        
        result = [item for item in l1 if item in l2]
        
        return result
    
    def list_difference(l1: List[Any], l2: List[Any]) -> List[Any]:
        
        """This function that takes two lists as  parameters and returns a new
        list with the values that are  in l1, but NOT in l2 using a list
        comprehension."""
        
        if not isinstance(l1, list):
            raise ValueError(f"Given {l1} is not a list")
        if not isinstance(l2, list):
            raise ValueError(f"Given {l2} is not a list")
        
        result : List[Any] = list()
        
        result = [item for item in l1 if item not in l2]
        
        return result
    
    def remove_vowels(string: str) -> str:
        
        """This function takes a string, splits the string on whitespace into
        words and returns a new string that includes only the words that do NOT
        begin with vowels."""
        
        if not isinstance(string, str) or not string or len(string.strip()) == 0:
            raise ValueError(f"Given {string} is not a valid String")
        
        string_list : List[str] = string.split()
        result : List[str] = list()
        
        result = [item for item in string_list if item[0].lower() not in ['a','e','i','o','u']]
        return " ".join(result)
    
    def check_pwd(password: str) -> bool:
        
        """This function takes a string as a parameter and returns a boolean
        value if all conditions below are satisfied."""
        
        if not isinstance(password, str) or not password or len(password.strip()) == 0:
            raise ValueError(f"Given {password} is not a valid String")
        
        lower_case_list : List[str] = [item for item in password if item.islower()]
        upper_case_list : List[str] = [item for item in password if item.isupper()]
        
        if password[0].isdigit() and len(lower_case_list) >= 1 and len(upper_case_list) >= 2:
            return True
        
        return False
    
    
class DonutQueue:
    
    cust_queue : List[Any] = list()
    
    def arrive(self, name: str, vip: bool) -> None:
        
        """This function used to note that a customer arrived."""
        
        if not isinstance(name, str) or not name or len(name.strip()) == 0:
            raise ValueError(f"Given {name} is not a valid String")
        if not isinstance(vip, bool):
            raise ValueError(f"Given {vip} is not a valid boolean value")
        
        if len(self.cust_queue) == 0:
            self.cust_queue.append([name, vip])
            return
        
        if vip == True:
           for index, item in enumerate(self.cust_queue):
              if item[1] == False:
                self.cust_queue.insert(index,[name, vip])
                return
        else:
            self.cust_queue.append([name, vip])   
        
    def next_customer(self) -> Optional[str]:
        
        """This function returns the name of the next customer to be served
        where all priority customers are served in the order they arrived
        before any non-priority customer.

        It returns none if there are no customers waiting
        """ 
        if len(self.cust_queue) == 0:
            return None
        
        return self.cust_queue.pop(0)[0]
    
    def waiting(self) -> Optional[str]:
        
        """This function returns a comma separated string with the names of the
        customers waiting in the order they will be served or None if there are
        no customers waiting."""
        
        if len(self.cust_queue) == 0:
            return None
        
        cust_waiting : List[str] = list()
       
        cust_waiting = [item[0] for item in self.cust_queue]
        
        return ", ".join(cust_waiting)     

def main() -> None:
    
    try:
      dq = DonutQueue()
    #   dq.arrive("Sujit", False)
    #   dq.arrive("Fei", False)
    #   dq.arrive("Prof JR", True)
    #   print(dq.waiting())
    #   dq.arrive("Nanda", True)
    #   print(dq.waiting())
    #   print(dq.next_customer())
    #   print(dq.next_customer())
    #   print(dq.next_customer())
    #   print(dq.waiting())
    #   print(dq.next_customer()) 
    except ValueError as e:  
       print(e)

if __name__ == '__main__':
    main()