"""This program accepts two fractions from user in form of numerator and
denominator.

It performs calculation operation on given fractions like add,
subtract,multiply and divides. It also checks if two fractions are equal
or not.
"""

"""
  Class Fraction initialize fraction with numerator and denominator.
  It performs calculation operation on given fractions.
"""

class Fraction:

    """This function initialize fraction with given numerator and denominator.

    If denominator is zero , it raise exception ValueError.
    numerator : numerator of fraction.
    denominator : denominator of fraction.
    Returns none.
    """

    def __init__(self, numerator: float, denominator: float) -> None:
        self.numerator : float = numerator
        if denominator == 0 :
            raise ValueError("Denominator is zero")
        else:
            self.denominator: float = denominator

    """
      This function perform addition of two fraction
      self : current fraction
      other : another fraction
      Returns : result of two fraction addition in form of fraction
    """

    def __add__(self, other: "Fraction") -> "Fraction":
        value1: float = self.numerator * other.denominator
        value2: float = other.numerator * self.denominator
        value3: float = self.denominator * other.denominator
        return Fraction(value1 + value2, value3)

    """
      This function perform subtraction of two fraction
      self : current fraction
      other : another fraction
      Returns : result of two fraction subtraction in form of fraction
    """

    def __sub__(self, other: "Fraction") -> "Fraction":
        value1: float = self.numerator * other.denominator
        value2: float = other.numerator * self.denominator
        value3: float = self.denominator * other.denominator
        return Fraction(value1 - value2, value3)

    """
      This function perform multiplication of two fraction
      self : current fraction
      other : another fraction
      Returns : result of two fraction multiplication in form of fraction
    """

    def __mul__(self, other: "Fraction") -> "Fraction":
        value1: float = self.numerator * other.numerator
        value2: float = self.denominator * other.denominator
        return Fraction(value1, value2)

    """
      This function perform division of two fraction
      self : current fraction
      other : another fraction
      Returns : result of two fraction division in form of fraction
    """

    def __truediv__(self, other: "Fraction") -> "Fraction":
        value1: float = self.numerator * other.denominator
        value2: float = self.denominator * other.numerator
        return Fraction(value1, value2)

    """
      This function checks if two fractions are equals or not.
      self : current fraction
      other : another fraction
      Returns : result as True if fractions are equals else False
    """

    def __eq__(self, other: "Fraction") -> bool:
        return (self.numerator * other.denominator) == (self.denominator * other.numerator)

    """
      This function checks if two fractions are  equals or not.
      self : current fraction
      other : another fraction
      Returns : result as True if fractions are not equals else False
    """

    def __ne__(self, other: "Fraction") -> bool:
        return (self.numerator * other.denominator) != (self.denominator * other.numerator)

    """
      This function checks if first fractions is less than  second.
      self : current fraction
      other : another fraction
      Returns : result as True if first fractions is less than  second else False
    """

    def __lt__(self, other: "Fraction") -> bool:
        return (self.numerator * other.denominator) < (self.denominator * other.numerator)

    """
      This function checks if first fractions is less than or equal to second.
      self : current fraction
      other : another fraction
      Returns : result as True if first fractions is less than or or equal to second else False
    """

    def __le__(self, other: "Fraction") -> bool:
        return (self.numerator * other.denominator) <= (self.denominator * other.numerator)

    """
      This function checks if first fractions is greater than  second.
      self : current fraction
      other : another fraction
      Returns : result as True if first fractions is greater than  second else False
    """

    def __gt__(self, other: "Fraction") -> bool:
        return (self.numerator * other.denominator) > (self.denominator * other.numerator)

    """
      This function checks if first fractions is greater than or equal to second.
      self : current fraction
      other : another fraction
      Returns : result as True if first fractions is greater than or or equal to second else False
    """

    def __ge__(self, other: "Fraction") -> bool:
        return (self.numerator * other.denominator) >= (self.denominator * other.numerator)

    """
      This function perform calculation operation on two fraction based on given operator.
      self : current fraction
      other : another fraction
      operator : Specify which operation to be perform
      Returns : result of fractions operation in form of fraction
    """

    def calculate(self, other: "Fraction", operator: str) -> "Fraction":
        if(operator == "+"):
            return self.__add__(other)
        elif(operator == "-"):
            return self.__sub__(other)
        elif(operator == "*"):
            return self.__mul__(other)
        elif(operator == "/"):
            return self.__truediv__(other)

    """
      This function perform checks equality  on two fraction based on given equality operator.
      self : current fraction
      other : another fraction
      operator : Specify which operation to be perform
      Returns : result of fractions operation in form of true or false
    """

    def checkEquality(self, other: "Fraction", operator: str) -> bool:
        if(operator == "=="):
            return self.__eq__(other)
        elif(operator == "!="):
            return self.__ne__(other)
        elif(operator == "<"):
            return self.__lt__(other)
        elif(operator == "<="):
            return self.__le__(other)
        elif(operator == ">"):
            return self.__gt__(other)
        elif(operator == ">="):
            return self.__ge__(other)

    """
     This function display fraction in form of string
     Returns : string representation of fraction
    """

    def __str__(self) -> str:
        return f"{self.numerator}/{self.denominator}"


"""
  Class Parameter accepts numerator and denominator of fraction from user and initialize them.
  It also accepts operator (+ ,- , *, / , ==) from user which specify what operation to be performed on fractions.
"""

class Parameter:

    """This function accepts input (numerator and denominator) from user if
    input is invalid it handles Exception ValueError.

    fracNum : specify number of fraction i.e fraction 1 or 2 and so on.
    fracPart : specify numerator or denominator of fraction.
    Returns input converting it into float number.
    """

    def acceptInput(self, fracNum: int, fracPart: str) -> float:
        while True:   
            value : float = input(f"Enter fraction {fracNum} {fracPart} : ")
            try:
                return float(value)
            except ValueError:
                print(f"given value {value} is not a number")

    """
      This function calls acceptInput() function to accept input from user.
      Once it accepts numerator and denominator it initialize fraction.
      fracNum : specify number of fraction i.e fraction 1 or 2 and so on.
      Returns fraction object.
    """

    def getFraction(self, fracNum: int) -> "Fraction":
        numerator: float = self.acceptInput(fracNum, "numerator")
        denominator: float = self.acceptInput(fracNum, "denominator")
        return Fraction(numerator, denominator)

    """
      This function accepts operator from user from given choice.
      Returns operator in form of string.
    """

    def acceptOperator(self) -> str:
        operator: str = input(
            f"Operation (+, -, *, /, ==, != , <, <= , > , >=): ")
        while True:
            if operator in ['+', '-', '*', '/', '==', '!=', '<', '<=', '>', '>=']:
                return operator
            else:
                print(f"given value {operator} is not a valid operator")
                operator = input(
                    f"Operation (+, -, *, /, ==, != , <, <= , > , >=): ")




"""
   It accepts two fraction from user and operator
   Continue to run application until user enters Quit.
"""


def main() -> None:
    flag: bool = True

    while flag:
        print("------------------------------------------------------")
        print("------------------------------------------------------")
        print('Welcome to the fraction calculator!')

        try:
            c1 = Parameter()
            # Initialize fraction 1 with numerator and denominator
            fraction1: Fraction = c1.getFraction(1)
            # accept operator from user
            operator: str = c1.acceptOperator()
            # Initialize fraction 2 with numerator and denominator
            fraction2: Fraction = c1.getFraction(2)

            # if operator is "==" ,then call function "equal" and display result.
            if operator in ['==', '!=', '<', '<=', '>', '>=']:
                print(
                    f"{fraction1} {operator} {fraction2} = {fraction1.checkEquality(fraction2, operator)}")
            else:
                # Perform operation on fraction1 and fraction2 and store result in fraction3
                fraction3: Fraction = fraction1.calculate(fraction2, operator)
                # prints result
                print(f"{fraction1} {operator} {fraction2} = {fraction3}")

            userInput = input(
                'If user want to quit press Q, else just enter : ')
            if userInput == "Q" or userInput == "q":
                flag = False

        except ValueError as e:
            print(f"Error : {e}")
            flag = False


if __name__ == '__main__':
    main()
