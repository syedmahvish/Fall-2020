import unittest
from HW03_Mahvish_Syed import Fraction


class FTest(unittest.TestCase):

    """This function test init method of fraction class.

    It also test ValueError Which occur if denominator is 0.
    """
    def test_init(self) -> None:
        self.assertTrue(Fraction(1, 2))
        self.assertRaises(ValueError, Fraction, 9,0)
        
    """This function test str method of fraction class.

    It test if str method prints fraction in intendend way or not
    """
    def test_str(self) -> None:
        f12 = Fraction(1, 2)
        self.assertTrue(str(f12) == '1/2')
        self.assertFalse(str(f12) == '0/2')

    """
      This function test addition of two fraction
      method assertTrue() is used to validate addition with desired result.
      Returns : result of two fraction addition in form of fraction
    """
    def test_add(self) -> None:
        f12 = Fraction(1, 2)
        f44 = Fraction(4, 4)
        f128 = Fraction(12, 8)
        f32 = Fraction(3, 2)

        self.assertTrue((f12 + f12) == Fraction(4, 4))
        self.assertTrue((f12 + f44) == Fraction(12, 8))
        self.assertTrue((f12 + f128) == Fraction(32, 16))
        self.assertTrue((f12 + f32) == Fraction(8, 4))

        self.assertFalse((f12 + f32) == Fraction(83, 4))

        self.assertTrue((f12 + f44 + f32) == Fraction(48, 16))

    """
      This function test subtraction of two fraction
      method assertTrue() is used to validate subtraction with desired result.
      Returns : result of two fraction subtraction in form of fraction
    """
    def test_minus(self) -> None:
        f12 = Fraction(1, 2)
        f44 = Fraction(4, 4)
        f128 = Fraction(12, 8)
        f32 = Fraction(3, 2)

        self.assertTrue((f12 - f12) == Fraction(0, 4))
        self.assertTrue((f44 - f12) == Fraction(4, 8))
        self.assertTrue((f12 - f128) == Fraction(-16, 16))
        self.assertTrue((f12 - f32) == Fraction(-4, 4))

        self.assertFalse((f12 - f32) == Fraction(2, 2))
        
        self.assertTrue((f12 - f44 - f32) == Fraction(-32, 16))

   
    """
      This function test multiplication of two fraction
      method assertTrue() is used to validate multiplication with desired result.
    """
    def test_mul(self) -> None:
        f12 = Fraction(1, 2)
        f44 = Fraction(4, 4)
        f128 = Fraction(12, 8)
        f32 = Fraction(3, 2)

        self.assertTrue((f12 * f12) == Fraction(1, 4))
        self.assertTrue((f44 * f12) == Fraction(4, 8))
        self.assertTrue((f12 * f128) == Fraction(12, 16))
        self.assertTrue((f12 * f32) == Fraction(3, 4))

        self.assertFalse((f12 * f32) == Fraction(9, 99))
        
        self.assertTrue((f12 * f44 * f32) == Fraction(12, 16))

    """
      This function test division of two fraction
      method assertTrue() is used to validate division with desired result.
    """
    def test_truediv(self) -> None:
        f12 = Fraction(1, 2)
        f44 = Fraction(4, 4)
        f128 = Fraction(12, 8)
        f32 = Fraction(3, 2)

        self.assertTrue((f12 / f12) == Fraction(2, 2))
        self.assertTrue((f44 / f12) == Fraction(8, 4))
        self.assertTrue((f12 / f128) == Fraction(8, 24))
        self.assertTrue((f12 / f32) == Fraction(2, 6))

        self.assertFalse((f12 / f32) == Fraction(3, -4))
        
        self.assertTrue((f12 / f44 / f32) == Fraction(8, 24))

    """
      This function test if two fraction are equal or not
      method assertTrue() is used to validate equality of fraction with desired output.
    """
    def test_eq(self) -> bool:
        f12 = Fraction(1, 2)
        f44 = Fraction(4, 4)
        f23 = Fraction(2.3, 4.0)

        self.assertTrue(f12 == f12)
        self.assertFalse(f44 == f12)
        
        self.assertTrue(f23 == f23)
        self.assertFalse(f23 == f12)
    
    """
      This function test if two fraction are equal or not
      method assertTrue() is used to validate non-equality of fraction with desired output.
    """
    def test_ne(self) -> None:
        f12 = Fraction(1, 2)
        f44 = Fraction(4, 4)
        f23 = Fraction(2.3, 4.0)

        self.assertTrue(f44 != f12)
        self.assertFalse(f12 != f12)
        
        self.assertTrue(f23 != f12)
        self.assertFalse(f23 != f23)  
     
    """
      This function test if one fraction is less than other fraction or not
      method assertTrue() is used to validate one fraction is less than other fraction or not with desired output.
    """   
    def test_lt(self) -> None:
        f12 = Fraction(1, 2)
        f44 = Fraction(4, 4)
        f23 = Fraction(2.3, 4.0)

        self.assertTrue(f12 < f44)
        self.assertFalse(f12 < f12)
        
        self.assertTrue(f12 < f23)
        self.assertFalse(f23 < f23) 
     
    """
      This function test if one fraction is less or equal to other fraction or not
      method assertTrue() is used to validate one fraction is less or equal to other fraction or not with desired output.
    """    
    def test_le(self) -> None:
        f12 = Fraction(1, 2)
        f44 = Fraction(4, 4)
        f23 = Fraction(2.3, 4.0)

        self.assertTrue(f12 <= f44)
        self.assertTrue(f12 <= f12)
        
        self.assertFalse(f44 <= f12)
        
        self.assertTrue(f12 <= f23)
        
    """
      This function test if one fraction is greater than other fraction or not
      method assertTrue() is used to validate one fraction is greater than other fraction or not with desired output.
    """
    def test_gt(self) -> None:
        f12 = Fraction(1, 2)
        f44 = Fraction(4, 4)
        f23 = Fraction(2.3, 4.0)

        self.assertTrue(f44 > f12)
        self.assertTrue(f23 > f12)
        
        self.assertFalse(f12 > f12)
        
    """
      This function test if one fraction is greater than or equal to other fraction or not
      method assertTrue() is used to validate one fraction is greater than or equal to other fraction or not with desired output.
    """
    def test_ge(self) -> None:
        f12 = Fraction(1, 2)
        f44 = Fraction(4, 4)
        f23 = Fraction(2.3, 4.0)

        self.assertTrue(f12 >= f12)
        self.assertTrue(f44 >= f12)
        self.assertTrue(f23 >= f12)
        
        self.assertFalse(f12 >= f44)   
            
        
       


if __name__ == '__main__':
    unittest.main()
