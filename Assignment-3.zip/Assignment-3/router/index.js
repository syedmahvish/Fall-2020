const showsRoute = require("./shows");

const constructorMethod = (app) => {
  app.use("/", showsRoute);

  app.use("*", (req, res) => {
    res.status(404).render("errors", {
      title: "Errors",
      errors: ["Invalid url"],
      hasErrors: true,
    });
    return;
  });
};

module.exports = constructorMethod;
