const express = require("express");
const router = express.Router();
const axios = require("axios").default;

const bluebird = require("bluebird");
const redis = require("redis");
const { inflate } = require("zlib");
const { count } = require("console");
const client = redis.createClient();

bluebird.promisifyAll(redis.RedisClient.prototype);
bluebird.promisifyAll(redis.Multi.prototype);

router.get("/", async (req, res, next) => {
  let cacheForHomePageExists = await client.getAsync("allShowsPage");
  if (cacheForHomePageExists) {
    res.send(cacheForHomePageExists);
  } else {
    next();
  }
});

router.get("/", async (req, res) => {
  try {
    let allShows = await axios.get("http://api.tvmaze.com/shows");

    res.render(
      "shows",
      {
        title: "All shows list",
        showList: allShows.data,
      },
      async function (err, html) {
        if (err) {
          displayError(res, err.message);
        }
        await client.setAsync("allShowsPage", html);
        res.send(html);
      }
    );
  } catch (error) {
    displayError(res, error.message);
  }
});

router.get("/show/:id", async (req, res, next) => {
  try {
    if (!req.params.id) {
      displayError(res, "Invalid show id");
    }

    let cacheForIndviPageExists = await client.getAsync(`${req.params.id}`);
    if (cacheForIndviPageExists) {
      res.send(cacheForIndviPageExists);
    } else {
      next();
    }
  } catch (error) {
    displayError(res, error.message);
  }
});

router.get("/show/:id", async (req, res) => {
  try {
    let show = await axios.get(`http://api.tvmaze.com/shows/${req.params.id}`);

    res.render(
      "singleShow",
      {
        title: "Shows",
        showData: show.data,
      },
      async function (err, html) {
        if (err) {
          displayError(res, err.message);
        }

        await client.setAsync(`${req.params.id}`, html);
        res.send(html);
      }
    );
  } catch (error) {
    displayError(res, error.message);
  }
});

router.post("/search", async (req, res, next) => {
  try {
    if (!req.body || !req.body.search || req.body.search.trim().length === 0) {
      displayError(res, "Invalid Search");
      return;
    }

    let cacheForSearchPageExists = await client.getAsync(`${req.body.search}`);
    if (cacheForSearchPageExists) {
      client.zincrby("search", 1, `${req.body.search}`);

      res.send(cacheForSearchPageExists);
    } else {
      next();
    }
  } catch (error) {
    displayError(res, error.message);
  }
});

router.post("/search", async (req, res) => {
  try {
    let searchShowList = await axios.get(
      `http://api.tvmaze.com/search/shows?q=${req.body.search}`
    );

    if (searchShowList.data.length === 0) {
      displayError(res, "No result found for given search");
      return;
    }

    let showList = [];

    for (let item of searchShowList.data) {
      showList.push(item["show"]);
    }

    client.zadd("search", 1, `${req.body.search}`);

    res.render(
      "shows",
      {
        title: "Shows List",
        showList: showList,
      },
      async function (err, html) {
        if (err) {
          displayError(res, err.message);
        }
        await client.setAsync(`${req.body.search}`, html);
        res.send(html);
      }
    );
  } catch (error) {
    displayError(res, error.message);
  }
});

router.get("/popularsearches", async (req, res) => {
  client.zrevrange("search", 0, -1, "withscores", function (
    err,
    listwithscores
  ) {
    if (err || listwithscores.length === 0) {
      displayError(res, "No search performed yet");
      return;
    }

    let toppopularList = [];

    let i = 0;
    let count = 10;
    while (count > 0 && i < listwithscores.length) {
      toppopularList.push(listwithscores[i]);
      i = i + 2;
      count = count - 1;
    }

    res.render("popularSearch", {
      title: "Search term",
      popularSearch: toppopularList,
    });
  });
});

function displayError(res, errorMessage) {
  res.status(404).render("errors", {
    title: "Errors",
    errors: [errorMessage],
    hasErrors: true,
  });
}

module.exports = router;
