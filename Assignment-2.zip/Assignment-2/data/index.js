const movie = require("./movies");
module.exports = { movie: movie };
