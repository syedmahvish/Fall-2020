let moviesArray = [];

let tittle = [
  "Dil Chahta hai",
  "3 idiots",
  "Barfi",
  "Bhaag Milkha Bhaag",
  "Kahani",
  "Jab we met",
  "Ganjhni",
  "Wake up Sid",
  "Hera Pheri",
  "Zindagi na mileygi doobara",
];

let shortDescription = [
  "Dil Chahta Hai (transl. The heart wants) is a 2001 Indian Hindi-language coming-of-age romantic comedy-drama film. ",
  "3 Idiots is a 2009 Indian Hindi-language coming-of-age comedy-drama film.",
  "Barfi! is a 2012 Indian comedy-drama film set in the 1970s.",
  "Bhaag Milkha Bhaag[6] (transl. Run Milkha run) is a 2013 Indian biographical sports drama.",
  "Kahaani (IPA: [kəˈɦaːni]; English transl. Story) is a 2012 Indian Hindi-language mystery thriller film.",
  "Jab We Met (English: When We Met) is a 2007 Indian romantic comedy film.",
  "Ghajini is a 2008 Indian Hindi-language action thriller. ",
  "Wake Up Sid is a 2009 Indian Hindi-language coming-of-age drama film. ",
  "Hera Pheri (transl. Monkey business) is a 2000 Indian Hindi-language comedy film. ",
  "The film's story follows three childhood friends, Arjun, Kabir, and Imraan, who reunite for a three-week road trip.",
];

let about = [
  "Dil Chahta Hai (transl. The heart wants) is a 2001 Indian Hindi-language coming-of-age romantic comedy-drama film, marking Farhan Akhtar's directorial debut, as well as his debut as a writer. Starring Aamir Khan, Saif Ali Khan, Akshaye Khanna, Preity Zinta, Sonali Kulkarni and Dimple Kapadia, the film is set in present-day urban Mumbai and Sydney, and focuses on a major period of transition in the romantic lives of three college-graduate friends.",
  "3 Idiots is a 2009 Indian Hindi-language coming-of-age comedy-drama film co-written (with Abhijat Joshi) and directed by Rajkumar Hirani. The film stars Aamir Khan, R. Madhavan, Sharman Joshi, Kareena Kapoor, Boman Irani and Omi Vaidya. The film follows the friendship of three students at an Indian engineering college and is a satire about the social pressures under an Indian education system.[6][7][8] The film is narrated through parallel dramas, one in the present and the other ten years in the past.",
  "Barfi! is a 2012 Indian comedy-drama film co-produced, written and directed by Anurag Basu. Set in the 1970s, the film depicts the story of Murphy Barfi Johnson (a deaf-mute boy from Darjeeling) and his relationships with two women, Shruti and Jhilmil (who is autistic). The film stars Ranbir Kapoor, Priyanka Chopra, and Ileana D'Cruz in the lead roles, with Saurabh Shukla, Ashish Vidyarthi, Jisshu Sengupta and Roopa Ganguly in supporting roles.",
  "Bhaag Milkha Bhaag[6] (transl. Run Milkha run) is a 2013 Indian biographical sports drama film directed by Rakeysh Omprakash Mehra from a script written by Prasoon Joshi. The story is based on the life of Milkha Singh, an Indian athlete who was a national champion runner and an Olympian. It stars Farhan Akhtar in the titular role with Sonam K Ahuja, Divya Dutta, Meesha Shafi, Pavan Malhotra, Yograj Singh, Art Malik and Prakash Raj in supporting roles. Sports was coordinated by the American action director Rob Miller of ReelSports.",
  "Kahaani (IPA: [kəˈɦaːni]; English transl. Story) is a 2012 Indian Hindi-language mystery thriller film co-written, co-produced and directed by Sujoy Ghosh. It stars Vidya Balan as Vidya Bagchi, a pregnant woman searching for her missing husband in Kolkata during the festival of Durga Puja, assisted by Satyoki Rana Sinha (Parambrata Chatterjee) and Khan (Nawazuddin Siddiqui).",
  "Jab We Met (English: When We Met) is a 2007 Indian romantic comedy film written and directed by Imtiaz Ali. The film, produced by Dhillin Mehta under Shree Ashtavinayak Cinevision Ltd, stars Kareena Kapoor and Shahid Kapoor in their fourth film together with Dara Singh, Pavan Malhotra and Saumya Tandon in supporting roles.Primarily based in Mumbai, Bathinda, and Shimla, Jab We Met tells the story of a feisty Punjabi girl, Geet Dhillon, who is sent off track when she bumps into a depressed Mumbai businessman, Aditya Kashyap, on an overnight train to Delhi. While attempting to get him back on board when he alights at a station stop, both are left stranded in the middle of nowhere. Having walked out of his corporate business after being dumped by his girlfriend, Aditya has no destination in mind, until Geet forces him to accompany her back home to her family, and then on to elope with her secret boyfriend, Anshuman.",
  "Ghajini is a 2008 Indian Hindi-language action thriller film written and directed by A. R. Murugadoss and produced by Allu Aravind, Tagore Madhu and Madhu Mantena. A remake of Murugadoss's own 2005 Tamil film of the same name starring Suriya and Asin, which in turn was reported to be inspired by the 2000 film Memento and the 1951 film Happy Go Lovely,[5][6] it stars Aamir Khan, Asin (who reprises her role in the Tamil original, thus making her Bollywood debut), Jiah Khan and Pradeep Rawat in lead roles, with Tinnu Anand, Sunil Grover, Khalid Siddiqui and Riyaz Khan in supporting roles. The score and soundtrack were composed by A. R. Rahman, while Aamir co-wrote an altered climax.Set in Mumbai, Ghajini follows the story of Sanjay Singhania, a businessman who develops anterograde amnesia following a violent encounter in which his love interest, a model named Kalpana, was killed. He tries to avenge the murder, committed by the eponymous gangster-turned-public figure, with the aid of photographs from a Polaroid Instant camera and permanent tattoos on his body",
  "Wake Up Sid is a 2009 Indian Hindi-language coming-of-age drama film written and directed by Ayan Mukerji and produced by Karan Johar's Dharma Productions, the film was distributed by UTV Motion Pictures, with visual effects contributed by the Prime Focus Group.[1] The film takes place in contemporary Mumbai and tells the story of a careless, rich brat Sid Mehra (Ranbir Kapoor), a college student who is taught the value of owning up to responsibility by Aisha (Konkona Sen Sharma), an aspiring writer from Kolkata. It was a critical and commercial success. Both Kapoor and Sharma won rave reviews for their performances, and Kapoor received awards and nominations for his acting.",
  "Hera Pheri (transl. Monkey business) is a 2000 Indian Hindi-language comedy film directed by Priyadarshan, starring Akshay Kumar, Sunil Shetty, Paresh Rawal and Tabu.[3] The screenplay is adapted from the 1989 Malayalam film Ramji Rao Speaking which was based on the one line of 1971 television film See The Man Run.[4] The film spawned a sequel, Phir Hera Pheri, released in 2006. It is the first instalment of the Hera Pheri franchise.",
  "The film's story follows three childhood friends, Arjun, Kabir, and Imraan, who reunite for a three-week road trip. They set off to Spain and meet Laila, who falls in love with Arjun and helps him overcome his compulsion to work. Kabir and his fiancée Natasha experience significant misunderstandings. During their trip, each friend chooses a dangerous sport for the group to partake in.",
];

let imageAddress = [
  "https://upload.wikimedia.org/wikipedia/en/d/db/Dil_Chahta_Hai.jpg",
  "https://upload.wikimedia.org/wikipedia/en/d/df/3_idiots_poster.jpg",
  "https://upload.wikimedia.org/wikipedia/en/2/2e/Barfi%21_poster.jpg",
  "https://upload.wikimedia.org/wikipedia/en/4/42/Bhaag_Milkha_Bhaag_poster.jpg",
  "https://upload.wikimedia.org/wikipedia/en/f/f2/Kahaani_poster.jpg",
  "https://upload.wikimedia.org/wikipedia/en/9/9f/Jab_We_Met_Poster.jpg",
  "https://upload.wikimedia.org/wikipedia/en/9/97/Ghajini_Hindi.jpg",
  "https://upload.wikimedia.org/wikipedia/en/9/9f/Wake_up_Sid.jpg",
  "https://upload.wikimedia.org/wikipedia/en/a/a5/Hera_Pheri_2000_poster.jpg",
  "https://upload.wikimedia.org/wikipedia/en/1/17/Zindagi_Na_Milegi_Dobara.jpg",
];

for (let index = 0; index < 10; index++) {
  let moviesDict = {
    tittle: tittle[index],
    about: about[index],
    image: imageAddress[index],
    shortDescription: shortDescription[index],
    id: "movieid" + index,
  };

  moviesArray.push(moviesDict);
}

module.exports = { moviesArray };
