const express = require("express");
const router = express.Router();
const data = require("../data");
const movieData = data.movie;

router.get("/", async (req, res) => {
  res.render("movies", {
    title: "Movies Check",
    movieDict: movieData.moviesArray,
  });
});

module.exports = router;
