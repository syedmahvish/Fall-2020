const moviesRoute = require("./movies");
const path = require("path");

const constructorMethod = (app) => {
  app.use("/", moviesRoute);

  app.use("*", (req, res) => {
    res.status(400).render("errors", {
      errors: ["Invalid url"],
      hasErrors: true,
      title: "Errors!!",
    });
    return;
  });
};

module.exports = constructorMethod;
